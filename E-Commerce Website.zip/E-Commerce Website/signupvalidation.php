<?php

	if(isset($_POST['submit']))
	{
		$name = trim($_POST['name']);
		$email = trim($_POST['email']);
		$password = $_POST['password'];
		$confirmpassword = $_POST['confirmpassword'];
		$dd = trim($_POST['dd']);
		$mm = trim($_POST['mm']);
		$yyyy = trim($_POST['yyyy']);
		$leapYearCheck = leapYear($yyyy);
		$februaryCheck = febCheck($mm);
		$day30Check = dayCheck30($mm);
		$address = trim($_POST['address']);
		$gender = trim($_POST['gender']);
		$usertype = trim($_POST['usertype']);
		if(empty($name))
		{
			echo "Cannot be empty.";
		}
		else if(checkWordNum($name))
		{
			echo "Contain at least two words.";
		}
		else if(ord($name[0])>=48 && ord($name[0])<=57)
		{
			echo "Must start with a letter.";
		}
		else if(checkWord($name))
		{
			echo "Can contain a-z, A-Z, period, dash only";
		}
		else if(empty($email))
		{
			echo "Can not be empty.";
		}
		else if(ord($email[0])==64 || ord($email[0])==46)
		{
			echo "Not a valid format.";
		}
		else if(checkSpace($email))
		{
			echo "Not a valid format.";
		}
		else if(countSingleChar($email))
		{
			echo "Not a valid format.";
		}
		else if(checkSingleChar($email))
		{
			echo "Not a valid format.";
		}
		else if(checkChar($email))
		{
			echo "Not a valid format.";
		}
		else if(checkDotCom($email))
		{
			echo "Not a valid format.";
		}
		else if(empty($password))
		{
			echo "Password be empty.";
		}
		else if(checkPassword($password))
		{
			echo "";
		}
		else if(empty($confirmpassword))
		{
			echo "Can not be empty.";
		}
		else if(matchPassword($password,$confirmpassword))
		{
			echo "Password does not match.";
		}
		else if(empty($_POST['gender']))
		{
			echo "At least one of them must be selected.<br/>";
		}
		else if(empty($dd))
		{
			echo "Can not be empty or 0.<br/>";
		}
		else if(empty($mm))
		{
			echo "Can not be empty or 0.<br/>";
		}
		else if(empty($yyyy))
		{
			echo "Can not be empty or 0.<br/>";
		}
		else if(checkYear($yyyy))
		{
			echo "Year should be 4 digit<br/>";
		}
		else if(checkMonth($mm))
		{
			echo "Month should be 1-12<br/>";
		}
		else if(checkDay($dd,$mm,$yyyy,$leapYearCheck,$februaryCheck,$day30Check))
		{
			if($februaryCheck==1 && $leapYearCheck==0)
			{
				echo "This month should have 1-28 days<br/>";
			}
			else if($februaryCheck==1 && $leapYearCheck==1)
			{
				echo "This month should have 1-29 days<br/>";
			}
			else if($day30Check==1)
			{
				echo "This month should have 1-30 days<br/>";
			}
			else
			{
				echo "This month should have 1-31 days<br/>";
			}
		}
		else if(empty($usertype))
		{
			echo "User type cannot be empty.<br/>";
		}
		else
		{
			echo "All Ok.<br/>";
			echo "Uploding file to databse.<br/>";
			//fileAppend($email,$password,$usertype);
			$dob = $dd."-".$mm."-".$yyyy;
			//echo "Date : ".$dob."<br/>";
			uploadData($name,$email,$password,$dob,$address,$usertype,$gender);
			echo "Data uploaded successfully...<br>/";
			header("Location:login.php");

		}
		
	}
	else if(isset($_POST['reset']))
	{
		header("Location:signup.php");
	}
	else
	{
		echo "You are not allowed.";
	}


	function uploadData($name,$email,$password,$dob,$address,$usertype,$gender)
	{
		$con=mysqli_connect("localhost","root","","db_connection");
		if(!$con)
		{
			die("Database not connected".mysqli_connect_error()."<br/>");
		}
		else
		{
			echo "Database connected successfully...<br/>";
		}
		$sql=array("null","null");
		$sql[0]="INSERT INTO login(email,password,user_type) VALUES('".$email."','".$password."','".$usertype."')";
		$sql[1]="INSERT INTO user_information(name,gender,date_of_birth,address) VALUES('".$name."','".$gender."',
		'".$dob."','".$address."')";
		for($i=0;$i<count($sql);$i++)
		{
			if(mysqli_query($con,$sql[$i]))
			{
				echo "Row added...<br/>";
			}
			else
			{
				echo "Adding failed: ".mysqli_connect_error($con)."<br/>";
			}
		}
	}

	function checkWordNum($name)
	{
		$ck = true;
		$spaceCount = 0;

		for($i=0;$i<strlen($name);$i++)
		{
			if(ord($name[$i])==32)
			{
				$spaceCount++;
			}
			else
			{
				//do nothing...
			}
		}

		if($spaceCount>=1)
		{
			$ck=false;
		}
		else
		{
			$ck=true;
		}

		return $ck;
	}
	
	function checkWord($name)
	{
		$ck = false;
		for($i=0;$i<strlen($name);$i++)
		{
			if( (ord($name[$i])>=65 && ord($name[$i])<=90) || (ord($name[$i])>=97 && ord($name[$i])<=122) || ord($name[$i])==45 || ord($name[$i])==32)
			{
				//do nothing...	
			}
			else
			{
				$ck  = true;
			}
		}
		return $ck;
	}
	
	function checkSpace($email)
	{
		$spaceCount = 0;
		for($i=0; $i<strlen($email); $i++)
		{
			if(ord($email[$i])==32)
			{
				for($j=$i; $j<strlen($email); $j++)
				{
					if(ord($email[$j])==32)
					{
						//do nothing...
					}
					else
					{
						$spaceCount++;
					}
				}
			}
			else
			{
				//comment...
			}
		}


		if($spaceCount==0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	function countSingleChar($email)
	{
		$atCount = 0;
		$dotCount = 0;
		for($i=0;$i<strlen($email);$i++)
		{
			if(ord($email[$i])==64)
			{
				$atCount++;
			}
			else if(ord($email[$i])==46)
			{
				$dotCount++;
			}
			else
			{
				//do nothing...
			}
		}

		if($atCount==1)
		{
			//echo "At Count = ".$atCount."<br/>";
			if($dotCount==1)
			{
				//echo "Dot Count = ".$dotCount."<br/>";
				return false;
			}
			else
			{
				return true;
			}
		}
		else
		{
			return true;
		}
	}


	function checkChar($email)
	{
		$ck = false;
		for($i=0;$i<strlen($email);$i++)
		{
			if( (ord($email[$i])>=65 && ord($email[$i])<=90) || (ord($email[$i])>=97 && ord($email[$i])<=122) 
				|| (ord($email[$i])>=48 && ord($email[$i])<=59)  || ord($email[$i])==64 || ord($email[$i])==32 || ord($email[$i])==95 || ord($email[$i])==46)
			{
				//do nothing...	
			}
			else
			{
				$ck  = true;
			}
		}
		return $ck;
	}

	function checkSingleChar($email)
	{
		$atValid = false;
		$dotValid = false;
		for ($i=0; $i <strlen($email) ; $i++) { 
			# code...
			if(ord($email[$i])==64)
			{
				if(ord($email[$i+1])==46 || ord($email[$i-1])==46)
				{
					$atValid = false;
				}
				else
				{
					$atValid = true;
					//echo "atValid = ".$atValid."<br/>";
				}
			}
			else if(ord($email[$i])==46)
			{
				if(($i+1)<strlen($email))
				{
					if(ord($email[$i+1])==64 || ord($email[$i-1])==64)
					{
						$dotValid = false;
					}
					else
					{
						$dotValid = true;
						//echo "dotValid = ".$atValid."<br/>";
					}
				}
			}
			else
			{
				//do nothing...
			}
		}

		if($atValid==1 && $dotValid==1)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	function checkDotCom($email)
	{	
		for($i=0; $i<strlen($email); $i++)
		{
			if(ord($email[$i])==46)
			{
				if(($i+3)<strlen($email))
				{
					if((ord($email[$i+1])==67 || ord($email[$i+1])==99) && (ord($email[$i+2])==79 || ord($email[$i+2])==111) && 
					(ord($email[$i+3])==77 || ord($email[$i+3])==109))
					{
						if(($i+4)<strlen($email))
						{
							if(ord($email[$i+4])==32)
							{
								return false;
							}
							else
							{
								return true;
							}
						}
						else
						{
							//do nothing...
						}
					}
					else
					{
						return true;
					}
				}
				else
				{
					return true;
				}
			}
			else
			{
				//do nothing...
			}
		}
	}

	
	function checkPassword($password)
	{
		$ck=true;
		$count = 0;
		if(strlen($password)>=8)
		{
			for($i=0;$i<strlen($password);$i++)
			{
				if(ord($password[$i])==36 || ord($password[$i])==36 || ord($password[$i])==37 || ord($password[$i])==64)
				{
					$count++;
				}
				else
				{
					//do nothing ...
				}
			}

			if($count>=1)
			{
				$ck=false;
			}
			else
			{
				$ck=true;
				echo "Special charecter count must be 1<br/>";
			}
		}
		else
		{
			echo "At least 8 charecters for password<br/>";
			$ck=true;
		}
		return $ck;
	}


	function matchPassword($password,$confirmpassword)
	{
		if($password===$confirmpassword)
		{
			return false;
		}
		else
		{
			return true;
		}
	}


	function checkDay($dd,$mm,$yyyy,$leapYearCheck,$februaryCheck,$day30Check)
	{
		$ck = false;
		$trueCount = 0;
		for($i=0;$i<strlen($mm);$i++)
		{
			if(ord($mm[$i])>=48 && ord($mm[$i])<=57)
			{
				$trueCount++;
			}
			else
			{
				//do nothing...
			}
		}

		if($trueCount==1 || $trueCount==2)
		{
			if($februaryCheck==1 && $leapYearCheck==0)
			{
				if(strlen($dd)==1)
				{
					if(ord($dd)>48 && ord($dd)<=57)
					{
						$ck = false;
					}
					else
					{
						$ck = true;
					}
				}
				else if(strlen($dd)==2)
				{
					if(ord($dd[0])==48)
					{
						if(ord($dd[1])==48)
						{
							$ck=true;
						}
						else
						{
							$ck=false;
						}
					}
					else if(ord($dd[0])==49)
					{
						// no need to do anything...
						$ck = false;
					}
					else if(ord($dd[0])==50)
					{
						if(ord($dd[1])<57)
						{
							$ck=false;
						}
						else
						{
							$ck=true;
						}
					}
					else
					{
						$ck = true;
					}
				}
				else
				{
					//do nothing...
				}
			}
			else if($februaryCheck==1 && $leapYearCheck===1)
			{
				if(strlen($dd)==1)
				{
					if(ord($dd)>48 && ord($dd)<=57)
					{
						$ck = false;
					}
					else
					{
						$ck = true;
					}
				}
				else if(strlen($dd)==2)
				{
					if(ord($dd[0])==48)
					{
						if(ord($dd[1])==48)
						{
							$ck=true;
						}
						else
						{
							$ck=false;
						}
					}
					else if(ord($dd[0])==49)
					{
						// no need to do anything...
						$ck = false;
					}
					else if(ord($dd[0])==50)
					{
						if(ord($dd[1])<=57)
						{
							$ck=false;
						}
						else
						{
							$ck=true;
						}
					}
					else
					{
						$ck = true;
					}
				}
				else
				{
					//do nothing...
				}
			}
			else if($day30Check==1)
			{
				if(strlen($dd)==1)
				{
					if(ord($dd)>48 && ord($dd)<=57)
					{
						$ck = false;
					}
					else
					{
						$ck = true;
					}
				}
				else if(strlen($dd)==2)
				{
					if(ord($dd[0])==48)
					{
						if(ord($dd[1])==48)
						{
							$ck=true;
						}
						else
						{
							$ck=false;
						}
					}
					else if(ord($dd[0])==49 || ord($dd[0])==50)
					{
						// no need to do anything...
						$ck = false;
					}
					else if(ord($dd[0])==51)
					{
						if(ord($dd[1])==48)
						{
							$ck=false;
						}
						else
						{
							$ck=true;
						}
					}
					else
					{
						$ck = true;
					}
				}
				else
				{
					//do nothing...
				}
			}
			else //for day 31...
			{
				if(strlen($dd)==1)
				{
					if(ord($dd)>48 && ord($dd)<=57)
					{
						$ck = false;
					}
					else
					{
						$ck = true;
					}
				}
				else if(strlen($dd)==2)
				{
					if(ord($dd[0])==48)
					{
						if(ord($dd[1])==48)
						{
							$ck=true;
						}
						else
						{
							$ck=false;
						}
					}
					else if(ord($dd[0])==49 || ord($dd[0])==50)
					{
						// no need to do anything...
						$ck = false;
					}
					else if(ord($dd[0])==51)
					{
						if(ord($dd[1])==48 || ord($dd[1])==49)
						{
							$ck=false;
						}
						else
						{
							$ck=true;
						}
					}
					else
					{
						$ck = true;
					}
				}
				else
				{
					//do nothing...
				}
			}
		}
		else
		{
			$ck = true;
		}
		return $ck;
	}

	function checkMonth($mm)
	{
		$ck = false;
		$trueCount = 0;
		for($i=0;$i<strlen($mm);$i++)
		{
			if(ord($mm[$i])>=48 && ord($mm[$i])<=57)
			{
				$trueCount++;
			}
			else
			{
				return true;
			}
		}
		//echo "<br/>".$trueCount."<br/>";
		if($trueCount==1 || $trueCount==2)
		{
			if(strlen($mm)==1)
			{
				//return false...
			}
			else if(strlen($mm)==2)
			{
				if(ord($mm[0])==48 && (ord($mm[1])>=49 && ord($mm[1])<=57))
				{
					$ck = false;
					//echo $ck."<br/>";	
				}
				else
				{
					$ck = true;
					//echo $ck."<br/>";
				}
			}
			else
			{
				$ck=true;
			}
		}
		else
		{
			$ck = true;
		}
		return $ck;
	}

	function checkYear($yyyy)
	{
		$ck = false;
		$trueCount = 0;
		for($i=0;$i<strlen($yyyy);$i++)
		{
			if(ord($yyyy[$i])>=48 && ord($yyyy[$i])<=57)
			{
				$trueCount++;
			}
			else
			{
				//do nothing...
			}
		}
		if($trueCount==4)
		{
			if($yyyy==0)
			{
				$ck=true;
				echo "Year can not be 0<br/>";
			}
			else
			{
				$ck=false;	
			}
			
		}
		else
		{
			$ck=true;
		}
		return $ck;
	}

	function leapYear($yyyy)
	{


		$trueCount = 0;
		for($i=0;$i<strlen($yyyy);$i++)
		{
			if(ord($yyyy[$i])>=48 && ord($yyyy[$i])<=57)
			{
				$trueCount++;
			}
			else
			{
				//do nothing...
			}
		}

		if($trueCount==4)
		{
			if(ord($yyyy%4)==48)
			{
				if(ord($yyyy%100)==48)
				{
					if(ord($yyyy%400)==48)
					{
						return 1;
					}
					else
					{
						return 0;
					}
				}
				else
				{
					return 1;
				}
			}
			else
			{
				return 0;
			}
		}
		else
		{
			echo "Format Error.<br/>";
		}
	}


	function febCheck($mm)
	{

		
		$trueCount = 0;
		for($i=0;$i<strlen($mm);$i++)
		{
			if(ord($mm[$i])>=48 && ord($mm[$i])<=57)
			{
				$trueCount++;
			}
			else
			{
				//do nothing...
			}
		}

		if($trueCount==1 || $trueCount==2)
		{
			if(ord($mm)>=48 && ord($mm)<=57)
			{
				$ck=false;
				if(ord($mm)==50)
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
			else
			{
				return 0;
			}
		}
		else
		{
			echo "Wrong Format<br/>";
		}

		
	}

	function dayCheck30($mm)
	{	


		$trueCount = 0;
		for($i=0;$i<strlen($mm);$i++)
		{
			if(ord($mm[$i])>=48 && ord($mm[$i])<=57)
			{
				$trueCount++;
			}
			else
			{
				//do nothing...
			}
		}


		if($trueCount==1 || $trueCount==2)
		{
			if(strlen($mm)==1)
			{
				if(ord($mm)==52 || ord($mm)==54 || ord($mm)==57)
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
			else
			{
				if(ord($mm[0])==49 && ord($mm[1]==49))
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
		}
		else
		{
			echo "Format Error<br/>";
		}
	}



	function fileAppend($email,$password,$usertype)
	{
		$file = fopen("file.txt", "a");
		fwrite($file, $email.",".$password."\n");
		fclose($file);

		$file2 = fopen("file2.txt", "a");
		fwrite($file2, $usertype."\n");
		fclose($file2);
	}
?>