<?php
session_start();
error_reporting(0);
?>
<!DOCTYPE html>
<html>
<head>
	<title>USER</title>
</head>
<body>
	<table border="1" width="100%" cellspacing="0">
		<tr height="50">
			<td align="center" width="5%" style="background-color:#333333">
				<a href="index.php"><img src="image0.png" height="50"></a>
			</td>
			<td align="center" width="15%" style="background-color:Orange">
				<h2><b>User Page</b></h2>
			</td>
			<td align="center" width="80%" style="background-color:Orange">
				<table border="1" width="100%" cellspacing="0">
						<tr height="50">
							<td width="85%" align="center">
								<input type="text" name="searchfield" size="150%" height="50">
								<input type="button" name="searchbutton" value="Search" onclick="location.href='search.php'">
							</td>
							<td width="5%" align="center">
								<input type="button" name="cart" value="Cart" onclick="location.href='cart.php'">
							</td>
							<td width="5%" align="center">
								<input type="button" name="logout" value="LogOut"onclick="location.href='login.php'">
							</td>
						</tr>
				</table>
			</td>
		</tr>
		<tr height="800">
			<td colspan="3" align="center">
				<table border="1" width="100%" cellspacing="0">
					<tr height="800">
						<td width="20%" valign="top">
							<table border="1" width="100%" cellspacing="0">
								<tr height="50">
									<td align="center">
										<a href="orderlist.php"><h2>My Orders</h2></a>
									</td>
								</tr>
								<tr height="50">
									<td align="center">
										<a href=""><h2>My List</h2></a>
									</td>
								</tr>
								<tr height="50">
									<td align="center">
										<a href="recommended.php"><h2>Recommended for me</h2></a>
									</td>
								</tr>
								<tr height="50">
									<td align="center">
										<a href="search.php"><h2>Store</h2></a>
									</td>
								</tr>
								<tr height="50">
									<td align="center">
										<div class="button"><a href="user.php?page=uploadProducts"><h2>Add Products</h2></a></div>
									</td>
								</tr>
								<tr height="50">
									<td align="center">
										<div class="button"><a href="user.php?page=updateProducts"><h2>See Products</h2></a></div>
									</td>
								</tr>
							</table>
						</td>
						<td width="80%" valign="top" align="center">
							<?php
								if($_GET['page']=="uploadProducts")
								{
									require_once("uploadProducts.php");
								}
								else if ($_GET['page']=="updateProducts") 
								{
									require_once("updateProducts.php");	
								}
								else
								{
									echo "Select Option Add Products.<br/>";
								} 
							?>
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr height="50" style="background-color:Orange">
			<td colspan="3">
				<table width="100%" cellpadding="0" border="0">
					<tr height="50">
						<td align="left" width="50%">
							&nbsp;&nbsp;&nbsp;<b><font color="red">CONTACT US :&nbsp;&nbsp;</font><a href="mailto:si.shehab1997@gmail.com">SI.SHEHAB1997@GMAIL.COM</a></b>
						</td>
						<td align="right" width="50%">
							© COPYRIGHT 2018 H CO.LTD ALL RIGHT RESERVED&nbsp;&nbsp;&nbsp;
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>