<!DOCTYPE html>
<html>
<head>
	<title>SignUp</title>
</head>
<body>
	<table border="1" width="100%" cellspacing="0">
		<tr height="50">
			<td align="center" width="5%" style="background-color:#333333">
				<a href="index.php"><img src="image0.png" height="50"></a>
			</td>
			<td align="center" width="15%" style="background-color:Orange">
				<h2><b>SignUp here</b></h2>
			</td>
			<td align="center" width="80%" style="background-color:Orange">
				<table border="1" width="100%" cellspacing="0">
						<tr height="50">
							<td width="85%" align="center">
								<input type="text" name="searchfield" size="150%" height="50">
								<input type="button" name="searchbutton" value="Search" onclick="location.href='search.php'">
							</td>
							<td width="5%" align="center">
								<input type="button" name="cart" value="Cart" onclick="location.href='cart.php'">
							</td>
							<td width="5%" align="center">
								<input type="button" name="login" value="LogIn" onclick="location.href='login.php'">
							</td>
						</tr>
				</table>
			</td>
		</tr>
		<tr height="800">
			<td colspan="3" align="center">
				<form method="post" action="signupvalidation.php">
					<table align="center" width="30%">
						<tr>
							<td align="left">
								<fieldset>
									<legend><h1>SignUp</h1></legend>
									<table>
										<tr>
											<td width="35%">
												Name
											</td>
											<td width="5%">:</td>
											<td width="40%">
												<input type="text" name="name" size="40" maxlength="40"><br/>
											</td>
											<td width="20%"></td>
										</tr>
									</table>
									<hr/>
									<table>
										<tr>
											<td width="35%">
												Email
											</td>
											<td width="5%">:</td>
											<td width="40%">
												<input type="text" name="email" size="40" maxlength="40">
											</td>
											<td width="20%"><a title="anything@example.com"><b>i</b></a></td>
										</tr>
									</table>
									<hr/>
									<table>
										<tr>
											<td width="35%">
												Password
											</td>
											<td width="5%">:</td>
											<td width="40%">
												<input type="password" name="password" size="40" maxlength="40"><br/>
											</td>
											<td width="20%"></td>
										</tr>
									</table>
									<hr/>
									<table>
										<tr>
											<td width="35%">
												Confirm Password
											</td>
											<td width="5%">:</td>
											<td width="40%">
												<input type="password" name="confirmpassword" size="40" maxlength="40"><br/>
											</td>
											<td width="20%"></td>
										</tr>
									</table>
									<hr/>
									<table>
										<tr>
											<td width="35%">
												Select User Type&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											</td>
											<td width="5%">&nbsp;&nbsp;&nbsp;:</td>
											<td width="40%">
												&nbsp;&nbsp;&nbsp;
												<select name="usertype">
													<option value=" "> </option>
													<option value="Admin">Admin</option>
													<option value="User">User</option>
												</select>
											</td>
											<td width="20%"></td>
										</tr>
									</table>
									<hr/>
									<table>
										<tr>
											<td width="35%">
												Address
											</td>
											<td width="5%">:</td>
											<td width="40%">
												<input type="text" name="address" size="40" maxlength="100"><br/>
											</td>
											<td width="20%"></td>
										</tr>
									</table>
									<hr/>
									<fieldset>
									<legend>GENDER</legend>
									<table>
										<tr>
											<td>
												<input type="radio" name="gender" value="male">Male
											</td>
											<td>
												<input type="radio" name="gender" value="female">Female
											</td>
											<td>
												<input type="radio" name="gender" value="other">Other
											</td>
										</tr>
									</table>
									</fieldset>
									<hr/>
									<fieldset>
									<legend>DATE OF BIRTH</legend>
									<table>
										<tr>
											<td><input align="center" type="text" name="dd" size="15" maxlength="2"></td>
											<td>/</td>
											<td><input type="text" name="mm" size="15" maxlength="2"></td>
											<td>/</td>
											<td><input type="text" name="yyyy" size="15" maxlength="4"></td>
											<td>(dd/mm/yyyy)</td>
										</tr>
									</table>
									</fieldset>
									<hr/>
									<input type="checkbox" name="t&c"><a href="t&c.php">I agree to all the terms & conditions</a>
									<hr/>
									<table width="100%">
										<tr>
											<td align="left">
												<input type="submit" value="Submit" name="submit">
												<input type="submit" value="Reset" name="reset">
											</td>
											<td align="right">
												<a href="login.php">Already have an account?</a>
											</td>
										</tr>
									</table>
								</fieldset>
							</td>
						</tr>
					</table>
				</form>
			</td>
		</tr>
		<tr height="50" style="background-color:Orange">
			<td colspan="3">
				<table width="100%" cellpadding="0" border="0">
					<tr height="50">
						<td align="left" width="50%">
							&nbsp;&nbsp;&nbsp;<b><font color="red">CONTACT US :&nbsp;&nbsp;</font><a href="mailto:si.shehab1997@gmail.com">SI.SHEHAB1997@GMAIL.COM</a></b>
						</td>
						<td align="right" width="50%">
							© COPYRIGHT 2018 H CO.LTD ALL RIGHT RESERVED&nbsp;&nbsp;&nbsp;
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>