<?php
session_start();
error_reporting(0);
?>
<!DOCTYPE html>
<html>
<head>
	<title>HOME</title>
</head>
<body>
	<form method="post" action="searchValidation.php">
		<table border="0" width="100%" align="center" cellspacing="0">
			<tr height="100" style="background-color:Orange">
				<td width="10%" align="center" style="background-color:#333333">
					<a href="index.php"><img src="image0.png" height="100"></a>
				</td>
				<td width="90%">
					<table border="0" width="100%" cellspacing="0">
						<tr height="40">
							<td width="85%" align="center">
								<input type="text" name="searchfield" size="150%" height="50">
								<input type="submit" name="searchbutton" value="Search">
							</td>
							<td width="5%" align="center">
								<input type="button" name="cart" value="Cart" onclick="location.href='cart.php'">
							</td>
							<td width="15%" align="center">
								<?php if($_SESSION['logged']==="true"){ ?>
									<?php if($_SESSION['usertype']==="Admin"){ ?>
										<input type="button" name="myPanel" value="Admin Panel" onclick="location.href='admin.php'">
									<?php }else{ ?>
										<input type="button" name="myPanel" value="User Panel" onclick="location.href='user.php'">
									<?php } ?>
									<input type="button" name="logout" value="LogOut" onclick="location.href='login.php'">
								<?php }else{ ?>
									<input type="button" name="login" value="LogIn" onclick="location.href='login.php'">
								<?php } ?>
							</td>
						</tr>
						<tr height="50">
							<td colspan="3">
								<table width="100%" border="1" align="center" cellspacing="0">
									<tr height="50">
										<td align="center" width="20%">
											<a href=""><font color="white"><b>HOME</b></font></a>
										</td>
										<td align="center" width="20%">
											<a href=""><font color="white"><b>BRAND</b></font></a>
										</td>
										<td align="center" width="20%">
											<a href=""><font color="white"><b>PRODUCT</b></font></a>
										</td>
										<td align="center" width="20%">
											<a href=""><font color="white"><b>NEWS</b></font></a>
										</td>
										<td align="center" width="20%">
											<a href=""><font color="white"><b>STORE</b></font></a>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr height="700" style="background-color:#333333">
				<td colspan="2" align="center">
					<a href=""><img src="image1.jpg" height="700"></a>
				</td>
			</tr>
			<tr height="850">
				<td colspan="2">
					<table border="0" cellspacing="0" align="center" width="100%">
						<tr height="850">
							<td width="50%" style="background-color:#ff5c33" align="center">
								<img src="image2.jpg" height="700">
							</td>
							<td width="50%">
								<table border="0" cellspacing="0" align="center" width="100%">
									<tr height="425" style="background-color:Orange">
										<td align="center">
											<a href="recommended.php"><font color="white"><h1><b><i>Recommended<br/>For U</i></b></h1></font></a>
										</td>
									</tr>
									<tr height="425" style="background-color:DodgerBlue">
										<td align="center">
											<a href="p&p.php"><font color="white"><h1><b><i>ABOUT US<br/>Privacy & Policy</i></b></h1></font></a>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr height="50" style="background-color:#333333;">
				<td colspan="3" align="center">
					<font color="white"><h2>-----Best Choice-----</h2></font>
				</td>
			</tr>
			<tr height="300">
				<td colspan="3">
					<table width="100%" border="0" cellspacing="1" height="300">
						<tr style="background-color:#333333" align="center">
							<td width="20%">
								<a href=""><font color="white"><b>Household Items</b></font></a>
							</td>
							<td width="20%">
								<a href=""><font color="white"><b>Daily Life Products</b></font></a>
							</td>
							<td width="20%">
								<a href=""><font color="white"><b>Health & Beauty</b></font></a>
							</td>
							<td width="20%">
								<a href=""><font color="white"><b>Digital Products</b></font></a>
							</td>
							<td width="20%">
								<a href=""><font color="white"><b>Food & Drinks</b></font></a>
							</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr height="500">
				<td colspan="3" style="background-color:#333333" align="center">
					<font color="white">Not implemented yet...</font>
				</td>
			</tr>
			<tr height="50">
				<td style="background-color:#333333" align="center" width="10%" colspan="3">
					<a href=""><font color="white"><b><i>MORE</i></b></font></a>
				</td>
			</tr>
			<tr height="50" style="background-color:Orange">
				<td colspan="3">
					<table width="100%" cellpadding="0" border="0">
						<tr height="50">
							<td align="left" width="50%">
								&nbsp;&nbsp;&nbsp;<b><font color="red">CONTACT US :&nbsp;&nbsp;</font><a href="mailto:si.shehab1997@gmail.com">SI.SHEHAB1997@GMAIL.COM</a></b>
							</td>
							<td align="right" width="50%">
								© COPYRIGHT 2018 H CO.LTD ALL RIGHT RESERVED&nbsp;&nbsp;&nbsp;
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</form>
</body>
</html>
								