<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="uploadProducts">
		<form method="post" action="uploadProductsValidation.php" enctype="multipart/form-data">
			<table border="1" cellspacing="0" >
				<tr height="50">
					<td colspan="4" align="center">
						ADD A NEW PRODUCT
					</td>
				</tr>
				<tr height="50">
					<td>
						Product Name
					</td>
					<td colspan="3">
						<input type="text" name="productName" maxlength="200" size="200">
					</td>
				</tr>
				<tr height="500">
					<td>
						Product Discription
					</td>
					<td colspan="3">
						<table border="1" cellspacing="0" width="100%">
							<tr height="50">
								<td>
									Discription Header
								</td>
								<td>
									<input type="text" name="text0" size="100">
								</td>
							</tr>
							<tr height="50">
								<td>
									Discription Sub-point-1
								</td>
								<td>
									<input type="text" name="text1" size="100">
								</td>
							</tr>
							<tr height="50">
								<td>
									Discription Sub-point-2
								</td>
								<td>
									<input type="text" name="text2" size="100">
								</td>
							</tr>
							<tr height="50">
								<td>
									Discription Sub-point-3
								</td>
								<td>
									<input type="text" name="text3" size="100">
								</td>
							</tr>
							<tr height="50">
								<td>
									Discription Sub-point-4
								</td>
								<td>
									<input type="text" name="text4" size="100">
								</td>
							</tr>
							<tr height="50">
								<td>
									Discription Sub-point-5
								</td>
								<td>
									<input type="text" name="text5" size="100">
								</td>
							</tr>
							<tr height="50">
								<td>
									Discription Sub-point-6
								</td>
								<td>
									<input type="text" name="text6" size="100">
								</td>
							</tr>
							<tr height="50">
								<td>
									Discription Sub-point-7
								</td>
								<td>
									<input type="text" name="text7" size="100">
								</td>
							</tr>
							<tr height="50">
								<td>
									Discription Sub-point-8
								</td>
								<td>
									<input type="text" name="text8" size="100">
								</td>
							</tr>
							<tr height="50">
								<td>
									Discription Sub-point-9
								</td>
								<td>
									<input type="text" name="text9" size="100">
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr height="400">
					<td>
						Images
					</td>
					<td>
						<table align="center" width="20%">
							<tr>
								<td align="left">
									<fieldset>
										<legend>Upload Image1</legend>
										<table border="1" cellspacing="0" width="100%">
											<tr>
												<td height="200"> 
													<img src="profilePicture.png" height="200"/>
												</td>
											</tr>
											<tr>
												<td>
													<input type="file" name="fileToUpload1" id="fileToUpload1">
												</td>
											</tr>
										</table>
									</fieldset>
								</td>
							</tr>
						</table>
					</td>
					<td>
						<table align="center" width="20%">
							<tr>
								<td align="left">
									<fieldset>
										<legend>Upload Image2</legend>
										<table border="1" cellspacing="0" width="100%">
											<tr>
												<td height="200"> 
													<img src="profilePicture.png" height="200"/>
												</td>
											</tr>
											<tr>
												<td>
													<input type="file" name="fileToUpload2" id="fileToUpload2">
												</td>
											</tr>
										</table>
									</fieldset>
								</td>
							</tr>
						</table>
					</td>
					<td>
						<table align="center" width="20%">
							<tr>
								<td align="left">
									<fieldset>
										<legend>Upload Image3</legend>
										<table border="1" cellspacing="0" width="100%">
											<tr>
												<td height="200"> 
													<img src="profilePicture.png" height="200"/>
												</td>
											</tr>
											<tr>
												<td>
													<input type="file" name="fileToUpload3" id="fileToUpload3">
												</td>
											</tr>
										</table>
									</fieldset>
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr height="50">
					<td colspan="4">
						<table width="100%" border="0" cellspacing="0">
							<tr>
								<td>
									Original Price 
								</td>
								<td>
									<input type="text" name="oprice" size="50">
								</td>
								<td>
									Sell Price 
								</td>
								<td>
									<input type="text" name="sprice" size="50">
								</td>
								<td>
									Inventory 
								</td>
								<td>
									<input type="text" name="inventory" size="50">
								</td>
								<td>
									Dicount
								</td>
								<td>
									<input type="text" name="discount">
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr height="50">
					<td colspan="4" align="right">
						<input type="submit" name="submit" value="Add Product">
					</td>
				</tr>
			</table>
		</form>
	</div>
</body>
</html>