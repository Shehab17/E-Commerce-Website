<?php
	session_start();
	if(isset($_POST['submit']))
	{
		
		$email = trim($_POST['email']);
		$password = trim($_POST['password']);
		$usertype ="";
		if(empty($email))
		{
			echo "Can not be empty.";
		}
		else if(ord($email[0])==64 || ord($email[0])==46)
		{
			echo "Not a valid format.";
		}
		else if(checkSpace($email))
		{
			echo "Not a valid format.";
		}
		else if(countSingleChar($email))
		{
			echo "Not a valid format.";
		}
		else if(checkSingleChar($email))
		{
			echo "Not a valid format.";
		}
		else if(checkChar($email))
		{
			echo "Not a valid format.";
		}
		else if(checkDotCom($email))
		{
			echo "Not a valid format.";
		}
		else if(empty($password))
		{
			echo "Cannot be empty.";
		}
		else if(checkPassword($password))
		{
			//do nothing
		}
		else
		{
			echo "All Ok.<br/>";
			echo "Checking Data...<br/>";
			//fileRead($email,$password);
			checkAccount($email,$password);
			
		}
		
	}
	else if(isset($_POST['reset']))
	{
		header("Location:login.php");
	}
	else
	{
		echo "You are not allowed.";
	}

	function checkAccount($email,$password)
	{
		$con=mysqli_connect("localhost","root","","db_connection");
		if(!$con)
		{
			die("Database not connected".mysqli_connect_error()."<br/>");
		}
		else
		{
			echo "Database connected successfully...<br/>";
		}
		$sql="SELECT * FROM login WHERE email='".$email."' and password='".$password."'";
		$result=mysqli_query($con,$sql);
		if(mysqli_num_rows($result)>0)
		{
			echo "Recoard fetched successfully...<br/>";
			while ($row=mysqli_fetch_array($result))
			{ 
				if($row['email']==$email && $row['password']==$password)
				{
					echo "Email: ".$row['email']."<br/>"." Password: ".$row['password']."<br/>Status: ".$row['status'].
					"<br/>";
					$_SESSION['id']=$row['user_id'];
					$_SESSION['usertype']=$row['user_type'];
					$_SESSION['logged']="true";
					header("Location:index.php");
				}
				else
				{
					echo "Email OR Password Error...<br/>OR Not Activated Yet...<br/>";
				}
			}
		}
		else
		{
			echo "No recoard found...<br/>";
		}
	}
	

	function checkSpace($email)
	{
		$spaceCount = 0;
		for($i=0; $i<strlen($email); $i++)
		{
			if(ord($email[$i])==32)
			{
				for($j=$i; $j<strlen($email); $j++)
				{
					if(ord($email[$j])==32)
					{
						//do nothing...
					}
					else
					{
						$spaceCount++;
					}
				}
			}
			else
			{
				//comment...
			}
		}


		if($spaceCount==0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	function countSingleChar($email)
	{
		$atCount = 0;
		$dotCount = 0;
		for($i=0;$i<strlen($email);$i++)
		{
			if(ord($email[$i])==64)
			{
				$atCount++;
			}
			else if(ord($email[$i])==46)
			{
				$dotCount++;
			}
			else
			{
				//do nothing...
			}
		}

		if($atCount==1)
		{
			//echo "At Count = ".$atCount."<br/>";
			if($dotCount==1)
			{
				//echo "Dot Count = ".$dotCount."<br/>";
				return false;
			}
			else
			{
				return true;
			}
		}
		else
		{
			return true;
		}
	}


	function checkChar($email)
	{
		$ck = false;
		for($i=0;$i<strlen($email);$i++)
		{
			if( (ord($email[$i])>=65 && ord($email[$i])<=90) || (ord($email[$i])>=97 && ord($email[$i])<=122) 
				|| (ord($email[$i])>=48 && ord($email[$i])<=59)  || ord($email[$i])==64 || ord($email[$i])==32 || ord($email[$i])==95 || ord($email[$i])==46)
			{
				//do nothing...	
			}
			else
			{
				$ck  = true;
			}
		}
		return $ck;
	}

	function checkSingleChar($email)
	{
		$atValid = false;
		$dotValid = false;
		for ($i=0; $i <strlen($email) ; $i++) { 
			# code...
			if(ord($email[$i])==64)
			{
				if(ord($email[$i+1])==46 || ord($email[$i-1])==46)
				{
					$atValid = false;
				}
				else
				{
					$atValid = true;
					//echo "atValid = ".$atValid."<br/>";
				}
			}
			else if(ord($email[$i])==46)
			{
				if(($i+1)<strlen($email))
				{
					if(ord($email[$i+1])==64 || ord($email[$i-1])==64)
					{
						$dotValid = false;
					}
					else
					{
						$dotValid = true;
						//echo "dotValid = ".$atValid."<br/>";
					}
				}
			}
			else
			{
				//do nothing...
			}
		}

		if($atValid==1 && $dotValid==1)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	function checkDotCom($email)
	{	
		for($i=0; $i<strlen($email); $i++)
		{
			if(ord($email[$i])==46)
			{
				if(($i+3)<strlen($email))
				{
					if((ord($email[$i+1])==67 || ord($email[$i+1])==99) && (ord($email[$i+2])==79 || ord($email[$i+2])==111) && 
					(ord($email[$i+3])==77 || ord($email[$i+3])==109))
					{
						if(($i+4)<strlen($email))
						{
							if(ord($email[$i+4])==32)
							{
								return false;
							}
							else
							{
								return true;
							}
						}
						else
						{
							//do nothing...
						}
					}
					else
					{
						return true;
					}
				}
				else
				{
					return true;
				}
			}
			else
			{
				//do nothing...
			}
		}
	}

	
	function checkPassword($password)
	{
		$ck=true;
		$count = 0;
		if(strlen($password)>=8)
		{
			for($i=0;$i<strlen($password);$i++)
			{
				if(ord($password[$i])==36 || ord($password[$i])==36 || ord($password[$i])==37 || ord($password[$i])==64)
				{
					$count++;
				}
				else
				{
					//do nothing ...
				}
			}

			if($count>=1)
			{
				$ck=false;
			}
			else
			{
				$ck=true;
				echo "Special charecter count must be 1<br/>";
			}
		}
		else
		{
			echo "At least 8 charecters for password<br/>";
			$ck=true;
		}
		return $ck;
	}

	function fileRead($email,$password)
	{
		$file = file("file.txt");
		$count = 0;
		$flag = 0;
		$matchedRow = 0;
		foreach($file as $data)
		{
			if(!empty($data))
			{
				echo "Data Found...!<br/>";
				if(($email.",".$password."\n")===$data)
				{
					echo "User existed...!<br/>";
					$count++;
					$matchedRow=$flag;
				}
				else
				{
					echo "User does not existed...!<br/>";
				}
			}
			else
			{
				echo "Empty Data...!<br/>";
			}
			$flag++;
		}
		if ($count==1) 
		{
			echo "Permission to login...<br/>";
			findUserType($matchedRow);
		}
		else
		{
			echo "Something went wrong...<br/>";
		}
	}
	

	function findUserType($matchedRow)
	{
		$flag2=0;
		echo $matchedRow."<br/>";
		$file2 = file("file2.txt");
		foreach($file2 as $data)
		{
			$file2=0;
			if(!empty($data))
			{
				if($flag2==$matchedRow)
				{
					echo $flag2."<br/>";
					echo $data."<br/>";
					if($data==("Admin"."\n"))
					{
						header("Location:admin.php");
					}
					else if($data==("User"."\n"))
					{
						header("Location:user.php");
					}
					else
					{
						echo "Else condition...";
					}

				}
				else
				{

				}
			}
			else
			{
				echo "Empty Data...(usertype)!<br/>";
			}
			$flag2++;
		}
	}
?>