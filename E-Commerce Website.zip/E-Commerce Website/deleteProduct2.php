<?php
	session_start();
	//error_reporting(0);
	//header("Location:user.php?page=updateProducts");
	if(!empty($_GET['id']))
	{
		$con=mysqli_connect("localhost","root","","db_connection");
		$sql="SELECT * FROM orders WHERE product_id='".$_GET['id']."' AND received=0";
		$result = mysqli_query($con,$sql);
		if(mysqli_num_rows($result)==0)
		{
			$sql2 = "DELETE FROM product_information WHERE user_id='".$_SESSION['id']."' AND product_id='".$_GET['id']."'";
			if(mysqli_query($con,$sql2))
			{
				echo "deleted";
				header("Location:user.php?page=updateProducts");
			}
			else
			{
				echo "not deleted";
			}
			//header("Location:user.php?page=updateProducts");
		}
		else
		{
			echo "Delete Error!<br/>";
			header("Location:user.php?page=updateProducts");
		}
	}
	
?>