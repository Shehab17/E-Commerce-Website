<?php

	//getting data from databse
	session_start();
	$con=mysqli_connect("localhost","root","","db_connection");
	$sql="SELECT * FROM orders WHERE user_id='".$_SESSION['id']."' AND received=0";
	$result=mysqli_query($con,$sql);
	$searchData = array();
	while ($row=mysqli_fetch_array($result)) {
		# code...
		$searchData[] = $row;
	}
	//returning response in JSON format
	echo json_encode($searchData);
	
?>