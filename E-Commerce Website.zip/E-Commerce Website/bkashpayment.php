<!DOCTYPE html>
<html>
<head>
	<title>bKash PAYMENT</title>
</head>
<body>
	<table border="1" width="100%" cellspacing="0">
		<tr height="50">
			<td align="center" width="5%" style="background-color:#333333">
				<a href="index.php"><img src="image0.png" height="50"></a>
			</td>
			<td align="center" width="15%" style="background-color:Orange">
				<h2><b>bKash Payment</b></h2>
			</td>
			<td align="center" width="80%" style="background-color:Orange">
				<table border="1" width="100%" cellspacing="0">
						<tr height="50">
							<td width="85%" align="center">
								<input type="text" name="searchfield" size="150%" height="50">
								<input type="button" name="searchbutton" value="Search" onclick="location.href='search.php'">
							</td>
							<td width="5%" align="center">
								<input type="button" name="cart" value="Cart" onclick="location.href='cart.php'">
							</td>
							<td width="5%" align="center">
								<input type="button" name="logout" value="LogOut" onclick="location.href='login.php'">
							</td>
						</tr>
				</table>
			</td>
		</tr>
		<tr height="800">
			<td colspan="3" align="center">
				<table width="30%" cellspacing="0" border="1">
					<tr height="25">
						<td align="center" colspan="2">
							This invoice is going to be expired within 48 hours
						</td>
					</tr>
					<tr height="50">
						<td align="center" colspan="2">
							<img src="image4.png">
						</td>
					</tr>
					<tr height="25">
						<td align="center" colspan="2">
							Pay from your personal bKash account.
						</td>
					</tr>
					<tr height="25">
						<td align="center" colspan="2">
							Backpack’s wallet: 017 57 869 069
						</td>
					</tr>
					<tr height="25">
						<td align="center" colspan="2">
							Or
						</td>
					</tr>
					<tr height="25">
						<td align="center" colspan="2">
							Scan QR code with bKash mobile app for faster payment
						</td>
					</tr>
					<tr height="100">
						<td align="center" colspan="2">
							<img src="image5.png">
						</td>
					</tr>
					<tr height="50">
						<td align="left" colspan="2">
							<h3>Pay $10,636</h3>
						</td>
					</tr>
					<tr height="50">
						<td align="left" colspan="2">
							Please remember:
							<ul>
								<li>Ours is a ​Merchant Wallet​.</li>
								<li>Use reference number 1 and counter number 1</li>
							</ul>
						</td>
					</tr>
					<tr height="25">
						<td align="left" colspan="2">
							Enter your 10-digit bKash transaction ID and click Pay:
						</td>
					</tr>
					<tr height="50">
						<td align="left" colspan="2">
							<input type="text" name="bkashtransactionid" size="40%">
						</td>
					</tr>
					<tr height="50">
						<td align="center">
							<input type="button" name="pay" value="Pay" onclick="location.href='bKashPaymentValidation.php'">
						</td>
						<td align="center">
							<input type="button" name="otherpaymentmethod" value="Other Payment Method" onclick="location.href='paymentmethods.php'">
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr height="50" style="background-color:Orange">
			<td colspan="3">
				<table width="100%" cellpadding="0" border="0">
					<tr height="50">
						<td align="left" width="50%">
							&nbsp;&nbsp;&nbsp;<b><font color="red">CONTACT US :&nbsp;&nbsp;</font><a href="mailto:si.shehab1997@gmail.com">SI.SHEHAB1997@GMAIL.COM</a></b>
						</td>
						<td align="right" width="50%">
							© COPYRIGHT 2018 H CO.LTD ALL RIGHT RESERVED&nbsp;&nbsp;&nbsp;
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>