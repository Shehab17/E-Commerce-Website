<?php

session_start();
$_SESSION['searchfield']=$_POST['searchfield'];
header("Location:search.php");
	
?>