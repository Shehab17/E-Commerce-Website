<?php
session_start();
error_reporting(0);
?>
<!DOCTYPE html>
<html>
<head>
	<title>CART</title>
</head>
<body>
	<?php
		if(!empty($_GET['id']))
		{
			if($_SESSION['logged']=="true"){
			$id = $_GET['id'];
			//echo $id."<br/>";
			$con=mysqli_connect("localhost","root","","db_connection");
			$sql1="SELECT * FROM cart WHERE product_id='".$_GET['id']."'";
			$result1=mysqli_query($con,$sql1);
			$row1=mysqli_fetch_array($result1);
			$productCount = $row1['product_count'];
			//echo $productCount."<br/>";
			if(mysqli_num_rows($result1)>0)
			{	
				//$message = "Product Already added.";
				//echo "<script type='text/javascript'>alert('$message');</script>";
				// $productCount++;
				// echo $productCount."<br/>";
				// $sql2 = "UPDATE cart SET product_count=".$productCount." WHERE product_id='".$_GET['id']."'";
				// if(mysqli_query($con,$sql2))
				// {
				// 	echo "Database Updated Successfully.<br/>";
				// }
				// else
				// {
				// 	echo "Failed to Update Database.<br/>";
				// }
			}
			else
			{
				$con2=mysqli_connect("localhost","root","","db_connection");
				$sql2 = "SELECT * FROM product_information WHERE product_id='".$id."'";
				$result2=mysqli_query($con2,$sql2);
				$row2=mysqli_fetch_array($result2);
				$sql3 = "INSERT INTO cart(product_count,user_id,product_id,product_name,sell_price,image) VALUES('1','".$_SESSION['id']."','".$_GET['id']."','".$row2['product_name']."','".$row2['sell_price']."','".$row2['image1']."')";
				if(mysqli_query($con,$sql3))
				{
					echo "Added to Database.<br/>";
				}
				else
				{
					echo "Addition Failed.<br/>";
				}
			}
			}
			else
			{
				echo "Please Login First.";
			}
		}
		else
		{

		}

	?>
	<table border="1" width="100%" cellspacing="0">
		<tr height="50">
			<td align="center" width="5%" style="background-color:#333333">
				<a href="index.php"><img src="image0.png" height="50"></a>
			</td>
			<td align="center" width="15%" style="background-color:Orange">
				<h2><b>Cart</b></h2>
			</td>
			<td align="center" width="80%" style="background-color:Orange">
				<table border="1" width="100%" cellspacing="0">
						<tr height="50">
							<td width="85%" align="center">
								<input type="text" name="searchfield" size="150%" height="50">
								<input type="button" name="searchbutton" value="Search" onclick="location.href='search.php'">
							</td>
							<td width="5%" align="center">
								<?php if($_SESSION['logged']==="true"){ ?>
									<input type="button" name="logout" value="LogOut" onclick="location.href='login.php'">
								<?php }else{ ?>
									<input type="button" name="login" value="LogIn" onclick="location.href='login.php'">
								<?php } ?>
							</td>
						</tr>
				</table>
			</td>
		</tr>
		<tr height="800">
			<td colspan="3" align="center" valign="top">
				<div class="cartValidation">
					<?php	
					if($_SESSION['logged']=="true"){
					require_once("cartValidation.php");
					}
					else
					{
						echo "Please Login First";
					}
					?>
				</div>
			</td>
		</tr>
		<tr height="50" style="background-color:Orange">
			<td colspan="3">
				<table width="100%" cellspacing="0" border="0">
					<tr height="50">
						<td align="left" width="50%">
							&nbsp;&nbsp;&nbsp;<b><font color="red">CONTACT US :&nbsp;&nbsp;</font><a href="mailto:smshabab36@gmail.com">SMSHABAB36@GMAIL.COM</a></b>
						</td>
						<td align="right" width="50%">
							© COPYRIGHT 2018 H CO.LTD ALL RIGHT RESERVED&nbsp;&nbsp;&nbsp;
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>