<!DOCTYPE html>
<html>
<head>
	<title>ADMIN</title>
</head>
<body>
	<table border="1" width="100%" cellspacing="0">
		<tr height="50">
			<td align="center" width="5%" style="background-color:#333333">
				<a href="index.php"><img src="image0.png" height="50"></a>
			</td>
			<td align="center" width="15%" style="background-color:Orange">
				<h2><b>Admin Page</b></h2>
			</td>
			<td align="center" width="80%" style="background-color:Orange">
				<table border="1" width="100%" cellspacing="0">
						<tr height="50">
							<td width="85%" align="center">
								<input type="text" name="searchfield" size="150%" height="50">
								<input type="button" name="searchbutton" value="Search" onclick="location.href='search.php'">
							</td>
							<td width="5%" align="center">
								<input type="button" name="cart" value="Cart" onclick="location.href='cart.php'">
							</td>
							<td width="5%" align="center">
								<input type="button" name="logout" value="LogOut" onclick="location.href='login.php'">
							</td>
						</tr>
				</table>
			</td>
		</tr>
		<tr height="800">
			<td colspan="3" align="center" valign="top">
				<table border="1" width="100%" cellspacing="0">
					<tr height="50">
						<td width="30%" align="center">
							<h2>General Information</h2>
						</td>
						<td width="30%" align="center">
							<h2>Manage User</h2>
						</td>
						<td width="40%" align="center">
							<h2>Reply To Users</h2>
						</td>
					</tr>
					<tr height="750">
						<td width="30%" valign="top">
							<table border="1" width="100%" cellspacing="0">
								<tr height="50">
									<td width="50%">
										Total Prducts:
									</td>
									<td width="50%">
										<input type="text" name="text1" value="4866">units
									</td>
								</tr>
								<tr height="50">
									<td width="50%">
										Product Sold:
									</td>
									<td width="50%">
										<input type="text" name="text2" value="865">units
									</td>
								</tr>
								<tr height="50">
									<td width="50%">
										Remain Product:
									</td>
									<td width="50%">
										<input type="text" name="text3" value="4001">units
									</td>
								</tr>
								<tr height="50">
									<td width="50%">
										Total sells:
									</td>
									<td width="50%">
										<input type="text" name="text4" value="5000">$
									</td>
								</tr>
								<tr height="50">
									<td width="50%">
										
									</td>
									<td width="50%">
										<input type="text" name="text5">
									</td>
								</tr>
								<tr height="50">
									<td width="50%">
										
									</td>
									<td width="50%">
										<input type="text" name="text6">
									</td>
								</tr>
								<tr height="50">
									<td width="50%">
										
									</td>
									<td width="50%">
										<input type="text" name="text7">
									</td>
								</tr>
							</table>
						</td>
						<td width="30%" valign="top">
							<table border="1" width="100%" cellspacing="0">
								<tr height=50>
									<td width="30%">
										Enter User Email:
									</td>
									<td width="70%" colspan="3">
										<input type="text" name="email" size="50%">
									</td>
								</tr>
								<tr>
									<td>
										<input type="button" name="checkuser" value="Check User">
									</td>
									<td>
										<input type="button" name="activateuser" value="Activate User">
									</td>
									<td>
										<input type="button" name="deactivateuser" value="Deactivate User">
									</td>
									<td>
										<input type="button" name="deleteuser" value="Delete User">
									</td>
								</tr>
							</table>
						</td>
						<td width="40%">
							<table border="1" width="100%" cellspacing="0">
								<tr height="750">
									<td width="30%">
										<table border="1" width="100%" cellspacing="0">
											<tr height="50">
												<td align="center">
													<input type="button" name="user1" value="Registered User-1">
												</td>
											</tr>
											<tr height="50">
												<td align="center">
													<input type="button" name="user2" value="Registered User-2">
												</td>
											</tr>
											<tr height="50">
												<td align="center">
													<input type="button" name="user3" value="Registered User-3">
												</td>
											</tr>
											<tr height="50">
												<td align="center">
													<input type="button" name="user4" value="Registered User-4">
												</td>
											</tr>
											<tr height="50">
												<td align="center">
													<input type="button" name="user5" value="Registered User-5">
												</td>
											</tr>
											<tr height="50">
												<td align="center">
													<input type="button" name="user6" value="Registered User-6">
												</td>
											</tr>
											<tr height="50">
												<td align="center">
													<input type="button" name="user7" value="Registered User-7">
												</td>
											</tr>
											<tr height="50">
												<td align="center">
													<input type="button" name="user8" value="Registered User-8">
												</td>
											</tr>
											<tr height="50">
												<td align="center">
													<input type="button" name="user9" value="Registered User-9">
												</td>
											</tr>
											<tr height="50">
												<td align="center">
													<input type="button" name="user10" value="Registered User-10">
												</td>
											</tr>
											<tr height="50">
												<td align="center">
													<input type="button" name="user11" value="Registered User-11">
												</td>
											</tr>
											<tr height="50">
												<td align="center">
													<input type="button" name="user12" value="Registered User-12">
												</td>
											</tr>
											<tr height="50">
												<td align="center">
													<input type="button" name="user13" value="Registered User-13">
												</td>
											</tr>
											<tr height="50">
												<td align="center">
													<input type="button" name="user14" value="Registered User-14">
												</td>
											</tr>
											<tr height="50">
												<td align="center">
													<input type="button" name="user15" value="Registered User-15">
												</td>
											</tr>
										</table>
									</td>
									<td width="70%" align="center">
										<textarea name="messgae" rows="40" cols="60">Enter text here...</textarea>
									</td>
								</tr>
								<tr height="50" align="right">
									<td colspan="2">
										<input type="button" name="send" value="Send Message">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr height="1100">
			<td align="center" valign="top" colspan="5">
				<table width="100%" cellspacing="0" border="1">
					<tr height="50">
						<td align="center" height="50">
							Inventory Management
						</td>
					</tr>
					<tr height="1000">
						<td align="center" height="1100">
							<table width="100%" cellspacing="0" border="1">
								<tr height="50" align="center">
									<td width="10%">product_name</td>
									<td width="10%">product_id</td>
									<td width="10%">stock_count</td>
									<td width="10%">stock_sold</td>
									<td width="10%">stock_left</td>
									<td width="10%">product_price</td>
									<td width="10%">product_catagory</td>
									<td width="10%">discount_in_%</td>
									<td width="10%">ratings(1-5)</td>
									<td width="10%"></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr height="50">
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
							</table>
						</td>
					</tr>
					<tr height="50">
						<td align="center" height="50">
							
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr height="50" style="background-color:Orange">
			<td colspan="3">
				<table width="100%" cellspacing="0" border="0">
					<tr height="50">
						<td align="left" width="50%">
							&nbsp;&nbsp;&nbsp;<b><font color="red">CONTACT US :&nbsp;&nbsp;</font><a href="mailto:si.shehab@gmail.com">SI.SHEHAB1997@GMAIL.COM</a></b>
						</td>
						<td align="right" width="50%">
							© COPYRIGHT 2018 H CO.LTD ALL RIGHT RESERVED&nbsp;&nbsp;&nbsp;
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>