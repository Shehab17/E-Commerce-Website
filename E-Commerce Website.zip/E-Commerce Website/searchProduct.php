<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<div class="mainBody">
		<div id="dynamic"></div>
		<script type="text/javascript">
			//call ajax
			var ajax = new XMLHttpRequest();
			var method = "GET";
			var url = "searchData.php";
			var asynchronous = true;
			ajax.open(method, url, asynchronous);
			//sending ajax request
			ajax.send();

			// receiving response from searchData.php  
			ajax.onreadystatechange = function()
			{
				if(this.readyState == 4 && this.status==200)
				{
					//converting JSON back to array
					var searchData = JSON.parse(this.responseText);
					console.log(searchData); //for debugging purpose
					var t = 0;
					var l = 0;
					for(var i=0; i<searchData.length; i++)
					{

						var id = searchData[i].product_id;
						var name = searchData[i].product_name;
						var image1 = searchData[i].image1;
						var sellPrice = searchData[i].sell_price;
						
						
						// let l=0;
						var val1 = document.createElement("IMG");
						val1.setAttribute("src", "image/"+image1);
						
						

						var val2 = document.createElement("table");
						val2.border = "0";
						val2.style.borderSpacing = "0";
						//val2.style.cssFloat = "left|right|none|initial|inherit" ;
						val2.width = "300";
						val2.innerHTML = "<tr><td colspan="+"2"+"><b>"+name+"</b></td></tr>"+
										"<tr><td colspan="+"2"+"><img src="+"image/"+image1+" width="+"300"+" height="+"300"+"></td></tr>"+
										"<tr><td><a href="+"product.php?id="+id+"><b>See Details</b></a></td><td align="+"right"+"><b>Price : "+sellPrice+"$<b></td></tr>";
						val2.style = "height:350px;align:left;margin:10px;padding:20px;position:flote;top:"+t+"px;left:"+l+"px;background-color:yellow;";

						document.getElementById("dynamic").appendChild(val2);

						l+=350;
						if(l>700)
						{
							l=0;
							t+=350;
						}
					}
				}
			};
		</script>
	</div>
</body>
</html>