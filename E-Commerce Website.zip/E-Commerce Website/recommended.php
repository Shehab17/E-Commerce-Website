<!DOCTYPE html>
<html>
<head>
	<title>RECOMMANDED</title>
</head>
<body>
	<table border="1" width="100%" cellspacing="0">
		<tr height="50">
			<td align="center" width="5%" style="background-color:#333333">
				<a href="index.php"><img src="image0.png" height="50"></a>
			</td>
			<td align="center" width="15%" style="background-color:Orange">
				<h2><b>Recommanded For U</b></h2>
			</td>
			<td align="center" width="80%" style="background-color:Orange">
				<table border="1" width="100%" cellspacing="0">
						<tr height="50">
							<td width="85%" align="center">
								<input type="text" name="searchfield" size="150%" height="50">
								<input type="button" name="searchbutton" value="Search" onclick="location.href='search.php'">
							</td>
							<td width="5%" align="center">
								<input type="button" name="cart" value="Cart" onclick="location.href='cart.php'">
							</td>
							<td width="5%" align="center">
								<input type="button" name="loign" value="LogIn" onclick="location.href='login.php'">
							</td>
						</tr>
				</table>
			</td>
		</tr>
		<tr height="1200">
			<td colspan="3">
				<table border="1" width="100%" cellspacing="0">
					<tr height="400">
						<td align="center" width="25%">
							<a href="product.php"><img src="image3.png" height="400"></a>
						</td>
						<td align="center" width="25%">
							<a href="">Product-2</a>
						</td>
						<td align="center" width="25%">
							<a href="">Product-3</a>
						</td>
						<td align="center" width="25%">
							<a href="">Product-4</a>
						</td>
					</tr>
					<tr height="400">
						<td align="center" width="25%">
							<a href="">Product-5</a>
						</td>
						<td align="center" width="25%">
							<a href="">Product-6</a>
						</td>
						<td align="center" width="25%">
							<a href="">Product-7</a>
						</td>
						<td align="center" width="25%">
							<a href="">Product-8</a>
						</td>
					</tr>
					<tr height="400">
						<td align="center" width="25%">
							<a href="">Product-9</a>
						</td>
						<td align="center" width="25%">
							<a href="">Product-10</a>
						</td>
						<td align="center" width="25%">
							<a href="">Product-11</a>
						</td>
						<td align="center" width="25%">
							<a href="">Product-12</a>
						</td>
					</tr>
					<tr height="50">
						<td align="center" colspan="4">
							Pages:&nbsp;&nbsp;
							<a href="">1</a>&nbsp;&nbsp;
							<a href="">2</a>&nbsp;&nbsp;
							<a href="">3</a>&nbsp;&nbsp;
							<a href="">4</a>&nbsp;&nbsp;
							<a href="">5</a>&nbsp;&nbsp;
							<a href="">6</a>&nbsp;&nbsp;
							<a href="">7</a>&nbsp;&nbsp;
							<a href="">8</a>&nbsp;&nbsp;
							<a href="">9</a>&nbsp;&nbsp;
							<a href="">10</a>
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr height="50" style="background-color:Orange">
			<td colspan="3">
				<table width="100%" cellpadding="0" border="0">
					<tr height="50">
						<td align="left" width="50%">
							&nbsp;&nbsp;&nbsp;<b><font color="red">CONTACT US :&nbsp;&nbsp;</font><a href="mailto:si.shehab1997@gmail.com">SI.SHEHAB1997@GMAIL.COM</a></b>
						</td>
						<td align="right" width="50%">
							© COPYRIGHT 2018 H CO.LTD ALL RIGHT RESERVED&nbsp;&nbsp;&nbsp;
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>