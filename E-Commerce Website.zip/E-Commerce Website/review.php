<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="review">
		<table width="100%" cellspacing="0" border="1" align="center">
			<?php 
			//echo $_GET['id']; 
			session_start();
			$con=mysqli_connect("localhost","root","","db_connection");
			$sql="SELECT * FROM reviews WHERE product_id='".$_GET['id']."'";
			$result=mysqli_query($con,$sql);
			if(mysqli_query($con,$sql))
			{
				while ($row=mysqli_fetch_array($result)) {
					# code...
		?>
					<tr height="100">
						<td valign="top">
							<?php echo $row['comments']; ?>
						</td>
					</tr>
		<?php
				}
			}
			else
			{

			}
		?>
		</table>
		<form action="reviewValidation.php?id=<?php echo($_GET['id']); ?>" method="post">
		<table width="100%" cellspacing="0" border="1" align="center">
			<tr height="50">
				<td>
					<input type="text" name="comments" size="180">
				</td>
				<td>
					<input type="submit" name="submit" value="Submit" onclick="location.href='reviewValidation.php?id=<?php
								echo($_GET['id']);
							?>'">
				</td>
			</tr>
		</table>
		</form>
	</div>
</body>
</html>