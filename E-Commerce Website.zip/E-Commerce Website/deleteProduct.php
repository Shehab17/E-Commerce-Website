<?php

session_start();
//error_reporting(0);


	if(!empty($_GET['id']))
	{
		$con=mysqli_connect("localhost","root","","db_connection");
		$sql="DELETE FROM cart WHERE product_id='".$_GET['id']."' AND user_id='".$_SESSION['id']."'";
		echo $sql."<br/>";
		if(mysqli_query($con,$sql))
		{
			echo "Successfully Deleted<br/>";
			header("Location:cart.php");
		}
		else
		{
			echo "Delete Error!<br/>";
		}
	}




?>