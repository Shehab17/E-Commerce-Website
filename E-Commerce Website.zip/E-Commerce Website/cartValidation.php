<?php
session_start();
//error_reporting(0);
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="cartValidation">
		<div id="cartValidation">
			<script type="text/javascript">
				//call ajax
				var ajax2 = new XMLHttpRequest();
				var method2 = "GET";
				var url2 = "searchData2.php";
				var asynchronous2 = true;
				ajax2.open(method2, url2, asynchronous2);
				//sending ajax request
				ajax2.send();




				ajax2.onreadystatechange = function()
				{
					if(this.readyState == 4 && this.status==200)
					{
						var searchData2 = JSON.parse(this.responseText);
						console.log(searchData2); //for debugging purpose
						var i = 0;
						var totalCost = 0;
						for(i; i<searchData2.length; i++)
						{

							var id = searchData2[i].product_id;
							var name = searchData2[i].product_name;
							var image = searchData2[i].image;
							var sellPrice = searchData2[i].sell_price;
							var productCount = searchData2[i].product_count;
							
							
							var val1 = document.createElement("IMG");
							val1.setAttribute("src", "image/"+image);

							

							var val2 = document.createElement("table");
							val2.border = "1";
							val2.cellspaceing = "0";
							val2.width = "80%";
							
							if(i==searchData2.length-1)
							{
								totalCost += sellPrice*productCount;
								val2.innerHTML ="<tr height="+"100"+">"+
												"<td width="+"20%"+" align="+"center"+">"+
													"<img src="+"image/"+image+" height="+"150"+">"+
												"</td>"+
												"<td width="+"40%"+">"+
													"<a style="+"text-decoration:none;"+" href="+"product.php?id="+id+"><b>"+name+"</b></a>"+
												"</td>"+
												"<td align="+"center"+" width="+"20%"+">"+
													"<a style="+"text-decoration:none;"+" href="+"deleteProduct.php?id="+id+">Delete Product</a><br/>"+
													"<a style="+"text-decoration:none;"+" href="+"minusButton.php?id="+id+"><h2>--</h2></a>Count:"+productCount+"<a style="+"text-decoration:none;"+" href="+"plusButton.php?id="+id+"><h2>+</h2></a>"+
												"</td>"+
												"<td width="+"20%"+" align="+"center"+">"+
													"Price:"+sellPrice*productCount+"$<br/>"+
												"</td>"+
											"</tr>"+
											"<tr height="+"50"+">"+
												"<td align="+"center"+" colspan="+"3"+">"+
													"<a style="+"text-decoration:none;"+" href="+"paymentmethods.php"+"><h2>Proceed To Payment</h2></a>"+
												"</td>"+
												"<td align="+"center"+" colspan="+"1"+">"+
													"<h3>Total: "+totalCost+"$</h3>"+
												"</td>"+
											"</tr>";
							}
							else
							{
								totalCost += sellPrice*productCount;
								val2.innerHTML ="<tr height="+"100"+">"+
												"<td width="+"20%"+" align="+"center"+">"+
													"<img src="+"image/"+image+" height="+"150"+">"+
												"</td>"+
												"<td width="+"40%"+">"+
													"<a style="+"text-decoration:none;"+" href="+"product.php?id="+id+"><b>"+name+"</b></a>"+
												"</td>"+
												"<td align="+"center"+" width="+"20%"+">"+
													"<a style="+"text-decoration:none;"+" href="+"deleteProduct.php?id="+id+">Delete Product</a><br/>"+
													"<a style="+"text-decoration:none;"+" href="+"minusButton.php?id="+id+"><h2>--</h2></a>Count:"+productCount+"<a style="+"text-decoration:none;"+" href="+"plusButton.php?id="+id+"><h2>+</h2></a>"+
												"</td>"+
												"<td width="+"20%"+" align="+"center"+">"+
													"Price:"+sellPrice*productCount+"$<br/>"+
												"</td>"+
											"</tr>";
							}
							
							

							document.getElementById("cartValidation").appendChild(val2);

							
						}
					}
				};
			</script>
		</div>
	</div>
</body>
</html>