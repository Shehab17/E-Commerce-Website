<?php
	session_start();
	$_SESSION['logged']="false";
?>

<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
</head>
<body>
	<form method="post" action="loginvalidation.php">
		<table border="1" width="100%" cellspacing="0">
		<tr height="50">
			<td align="center" width="5%" style="background-color:#333333">
				<a href="index.php"><img src="image0.png" height="50"></a>
			</td>
			<td align="center" width="15%" style="background-color:Orange">
				<h2><b>LogIn here</b></h2>
			</td>
			<td align="center" width="80%" style="background-color:Orange">
				<table border="1" width="100%" cellspacing="0">
						<tr height="50">
							<td width="85%" align="center">
								<input type="text" name="searchfield" size="150%" height="50">
								<input type="button" name="searchbutton" value="Search" onclick="location.href='search.php'">
							</td>
							<td width="5%" align="center" colspan="2">
								<input type="button" name="cart" value="Cart" onclick="location.href='cart.php'">
							</td>
						</tr>
				</table>
			</td>
		</tr>
		<tr height="800">
			<td colspan="3" align="center">
				<form method="post" action="loginvalidation.php">
					<table align="center" width="30%">
						<tr>
							<td align="left">
								<fieldset>
									<legend><h1>LogIn</h1></legend>
									<table>
										<tr>
											<td width="35%">
												Email
											</td>
											<td width="5%">:</td>
											<td width="40%">
												<input type="text" name="email" size="40" maxlength="40">
											</td>
											<td width="20%"><a title="anything@example.com"><b>i</b></a></td>
										</tr>
									</table>
									<hr/>
									<table>
										<tr>
											<td width="35%">
												Password
											</td>
											<td width="5%">:</td>
											<td width="40%">
												<input type="password" name="password" size="40" maxlength="40"><br/>
											</td>
											<td width="20%"></td>
										</tr>
									</table>
									<hr/>
									<table width="100%">
										<tr>
											<td align="left">
												<input type="submit" value="Submit" name="submit">
												<input type="submit" value="Reset" name="reset">
											</td>
											<td align="right">
												<input type="checkbox" name="rememberme">
												Remember Me.
											</td>
										</tr>
										<tr>
											<td align="center" colspan="2">
												<a href="signup.php">Don't have an account!</a>
											</td>
										</tr>
									</table>
								</fieldset>
							</td>
						</tr>
					</table>
				</form>
			</td>
		</tr>
		<tr height="50" style="background-color:Orange">
			<td colspan="3">
				<table width="100%" cellpadding="0" border="0">
					<tr height="50">
						<td align="left" width="50%">
							&nbsp;&nbsp;&nbsp;<b><font color="red">CONTACT US :&nbsp;&nbsp;</font><a href="mailto:si.shehab1997@gmail.com">SI.SHEHAB1997@GMAIL.COM</a></b>
						</td>
						<td align="right" width="50%">
							© COPYRIGHT 2018 H CO.LTD ALL RIGHT RESERVED&nbsp;&nbsp;&nbsp;
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
</body>
</html>