<!DOCTYPE html>
<html>
<head>
	<title>PRODUCT DETAILS</title>
</head>
<body>
	<?php
		$con=mysqli_connect("localhost","root","","db_connection");
		$sql="SELECT * FROM product_information WHERE product_id=".$_GET['id'];;
		$result=mysqli_query($con,$sql);
		$productName = "";
		$image1 = "";
		$image2 = "";
		$image3 = "";
		$descriptionHeader = "";
		$subPoint1 = "";
		$subPoint2 = "";
		$subPoint3 = "";
		$subPoint4 = "";
		$subPoint5 = "";
		$subPoint6 = "";
		$subPoint7 = "";
		$subPoint8 = "";
		$subPoint9 = "";
		$totalInventory = "";
		$soldProducts = "";
		$remaningProducts = "";
		$originalPrice = "";
		$sellPrice = "";
		$revenue = "";
		$discount = "";
		$sellerID = "";
		while ($row=mysqli_fetch_array($result)) {
			# code...
			$productName = $row['product_name'];
			$image1 = $row['image1'];
			$image2 = $row['image2'];
			$image3 = $row['image3'];
			$descriptionHeader = $row['description_header'];
			$subPoint1 = $row['sub_point_1'];
			$subPoint2 = $row['sub_point_2'];
			$subPoint3 = $row['sub_point_3'];
			$subPoint4 = $row['sub_point_4'];
			$subPoint5 = $row['sub_point_5'];
			$subPoint6 = $row['sub_point_6'];
			$subPoint7 = $row['sub_point_7'];
			$subPoint8 = $row['sub_point_8'];
			$subPoint9 = $row['sub_point_9'];
			$totalInventory = $row['total_inventory'];
			$soldProducts = $row['sold_products'];
			$remaningProducts = $row['remaining_products'];
			$originalPrice = $row['original_price'];
			$sellPrice = $row['sell_price'];
			$revenue = $row['revenue'];
			$discount = $row['discount'];
			$sellerID = $row['user_id'];
		}
	?>
	<form method="post" action="cart.php">
	<table border="1" width="100%" cellspacing="0">
		<tr height="50">
			<td align="center" width="5%" style="background-color:#333333">
				<a href="index.php"><img src="image0.png" height="50"></a>
			</td>
			<td align="center" width="15%" style="background-color:Orange">
				<h2><b>Product Details</b></h2>
			</td>
			<td align="center" width="80%" style="background-color:Orange">
				<table border="1" width="100%" cellspacing="0">
						<tr height="50">
							<td width="85%" align="center">
								<input type="text" name="searchfield" size="150%" height="50">
								<input type="button" name="searchbutton" value="Search" onclick="location.href='search.php'">
							</td>
							<td width="5%" align="center">
								<input type="button" name="cart" value="Cart" onclick="location.href='cart.php'">
							</td>
							<td width="5%" align="center">
								<input type="button" name="search" value="LogIn" onclick="location.href='login.php'">
							</td>
						</tr>
				</table>
			</td>
		</tr>
		<tr height="900">
			<td colspan="3">
				<table border="1" width="100%" cellspacing="0">
					<tr height="500">
						<td width="30%" align="center">
							<img src="image/<?php echo $image1; ?>" height="500">
						</td>
						<td width="50%">
							<table border="1" width="100%" cellspacing="0">
								<tr height="50">
									<td width="20%" align="center">
										<h3>NAME</h3>
									</td>
									<td width="80%">
										<h3><?php echo $productName; ?></h3>
									</td>
								</tr>
								<tr height="50">
									<td align="left" colspan="2">
										<h2><?php echo $descriptionHeader; ?></h2>

										<ul>
											<li><?php echo $subPoint1; ?></li>
											<li><?php echo $subPoint2; ?></li>
											<li><?php echo $subPoint3; ?></li>
											<li><?php echo $subPoint4; ?></li>
											<li><?php echo $subPoint5; ?></li>
											<li><?php echo $subPoint6; ?></li>
											<li><?php echo $subPoint7; ?></li>
											<li><?php echo $subPoint8; ?></li>
											<li><?php echo $subPoint9; ?></li>
										</ul>
										
									</td>
								</tr>
							</table>
						</td>
						<td width="20%" align="center">
							<h2>Price: $<?php echo $sellPrice; ?></h2>
							<br/>
							<input type="button" name="addtocart" value="Add To Cart" onclick="location.href='cart.php?id=<?php
								echo($_GET['id']);
							?>'">
						</td>
					</tr>
					<tr height="400">
						<td colspan="2">
					</form>
							<table border="1" width="100%" cellspacing="0">
								<tr height="50">
									<td align="center">
										REVIEWS
									</td>
								</tr>
								<tr height="350">
									<td valign="top">
										<div class="review">
											<?Php 
												require_once("review.php");
											?>
										</div>
									</td>
								</tr>
							</table>
						</td>
						
					</tr>
				</table>
			</td>
		</tr>
		<tr height="50" style="background-color:Orange">
			<td colspan="3">
				<table width="100%" cellpadding="0" border="0">
					<tr height="50">
						<td align="left" width="50%">
							&nbsp;&nbsp;&nbsp;<b><font color="red">CONTACT US :&nbsp;&nbsp;</font><a href="mailto:si.shehab1997@gmail.com">SI.SHEHAB1997@GMAIL.COM</a></b>
						</td>
						<td align="right" width="50%">
							© COPYRIGHT 2018 H CO.LTD ALL RIGHT RESERVED&nbsp;&nbsp;&nbsp;
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	
</body>
</html>