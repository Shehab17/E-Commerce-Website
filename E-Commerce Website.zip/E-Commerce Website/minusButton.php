<?php

session_start();
//error_reporting(0);


	if(!empty($_GET['id']))
	{	
		$id = $_GET['id'];
			echo $id."<br/>";
			$con=mysqli_connect("localhost","root","","db_connection");
			$sql1="SELECT * FROM cart WHERE product_id='".$_GET['id']."'";
			$result1=mysqli_query($con,$sql1);
			$row1=mysqli_fetch_array($result1);
			$productCount = $row1['product_count'];
			echo $productCount."<br/>";
			if($productCount>1)
			{
				if(mysqli_num_rows($result1)>0)
				{	
					$message = "Product Already added.";
					echo "<script type='text/javascript'>alert('$message');</script>";
					$productCount--;
					echo $productCount."<br/>";
					$sql2 = "UPDATE cart SET product_count=".$productCount." WHERE product_id='".$_GET['id']."'";
					if(mysqli_query($con,$sql2))
					{
						echo "Database Updated Successfully.<br/>";
						header("Location:cart.php");
					}
					else
					{
						echo "Failed to Update Database.<br/>";
					}
				}
			}
			else
			{
				$message = "Product Count Cannot Be Negetive OR 0.<br/>";
				echo "<script type='text/javascript'>alert('$message');</script>";
				header("Location:cart.php");
			}
			
		
	}




?>