<?php
session_start();
error_reporting(0);
?>
<!DOCTYPE html>
<html>
<head>
	<title>SEARCH</title>
</head>
<body>
	<form method="post" action="searchValidation.php">
		<table border="0" width="100%" cellspacing="0">
		<tr height="50">
			<td align="center" width="5%" style="background-color:#333333">
				<a href="index.php"><img src="image0.png" height="50"></a>
			</td>
			<td align="center" width="15%" style="background-color:Orange">
				<h2><b>Search By Category</b></h2>
			</td>
			<td align="center" width="80%" style="background-color:Orange">
				<table border="1" width="100%" cellspacing="0">
						<tr height="50">
							<td width="85%" align="center">
								<input type="text" name="searchfield" size="150%" height="50">
								<input type="submit" name="searchbutton" value="Search">
							</td>
							<td width="5%" align="center">
								<input type="button" name="cart" value="Cart" onclick="location.href='cart.php'">
							</td>
							<td width="5%" align="center">
								<?php if($_SESSION['logged']==="true"){ ?>
									<input type="button" name="logout" value="LogOut" onclick="location.href='login.php'">
								<?php }else{ ?>
									<input type="button" name="login" value="LogIn" onclick="location.href='login.php'">
								<?php } ?>
							</td>
						</tr>
				</table>
			</td>
		</tr>
		<tr height="850">
			<td width="20%" colspan="2" style="background-color:#333333" valign="top">
				<table border="1" width="100%" cellspacing="0" align="center">
					<tr height="50">
						<td align="center" >
							<h2><b><font color="white">Amount Under:
								<input type="" name="">$</font></b></h2>
						</td>
					</tr>
					<tr height="50">
						<td align="center">
							<h2><b><font color="white">Amount Above:
								<input type="" name="">$</font></b></h2>
						</td>
					</tr>
					<tr height="50">
						<td align="center">
							<a href=""><h2><b><font color="white">Amount Between:
								<input type="" name="" size="5%">-<input type="" name="" size="5%">$</font></b></h2></a>
						</td>
					</tr>
					<tr height="50">
						<td align="center">
							<a href=""><h2><b><font color="white">Top Sells</font></b></h2></a>
						</td>
					</tr>
					<tr height="50">
						<td align="center">
							<a href=""><h2><b><font color="white">New Product</font></b></h2></a>
						</td>
					</tr>
					<tr height="50">
						<td align="center">
							<a href=""><h2><b><font color="white">Category-6</font></b></h2></a>
						</td>
					</tr>
					<tr height="50">
						<td align="center">
							<a href=""><h2><b><font color="white">Category-7</font></b></h2></a>
						</td>
					</tr>
					<tr height="50">
						<td align="center">
							<a href=""><h2><b><font color="white">Category-8</font></b></h2></a>
						</td>
					</tr>
					<tr height="50">
						<td align="center">
							<a href=""><h2><b><font color="white">Category-9</font></b></h2></a>
						</td>
					</tr>
					<tr height="50">
						<td align="center">
							<a href=""><h2><b><font color="white">Category-10</font></b></h2></a>
						</td>
					</tr>
					<tr height="50">
						<td align="center">
							<a href=""><h2><b><font color="white">Category-11</font></b></h2></a>
						</td>
					</tr>
					<tr height="50">
						<td align="center">
							<a href=""><h2><b><font color="white">Category-12</font></b></h2></a>
						</td>
					</tr>
				</table>
			</td>
			<td width="80%">
				<table border="1" width="100%" cellspacing="0">
					<tr height="800">
						<td align="left" valign="top">
							<div class="mainBody">
								<?php	
									require_once("searchProduct.php");
								?>
							</div>
						</td>
					</tr>
					<tr height="50">
						<td align="center" colspan="3">
							Pages:&nbsp;&nbsp;
							<a href="">1</a>&nbsp;&nbsp;
							<a href="">2</a>&nbsp;&nbsp;
							<a href="">3</a>&nbsp;&nbsp;
							<a href="">4</a>&nbsp;&nbsp;
							<a href="">5</a>&nbsp;&nbsp;
							<a href="">6</a>&nbsp;&nbsp;
							<a href="">7</a>&nbsp;&nbsp;
							<a href="">8</a>&nbsp;&nbsp;
							<a href="">9</a>&nbsp;&nbsp;
							<a href="">10</a>
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr height="50" style="background-color:Orange">
			<td colspan="3">
				<table width="100%" cellpadding="0" border="0">
					<tr height="50">
						<td align="left" width="50%">
							&nbsp;&nbsp;&nbsp;<b><font color="red">CONTACT US :&nbsp;&nbsp;</font><a href="mailto:si.shehab1997@gmail.com">SI.SHEHAB1997@GMAIL.COM</a></b>
						</td>
						<td align="right" width="50%">
							© COPYRIGHT 2018 H CO.LTD ALL RIGHT RESERVED&nbsp;&nbsp;&nbsp;
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
</body>
</html>