<?php
	session_start();
	error_reporting(0);
	date(format,[timestamp]);
	$date = date("Y-m-d");
	echo $date."<br/>";
	$con=mysqli_connect("localhost","root","","db_connection");
	$sql1="SELECT * FROM cart WHERE user_id='".$_SESSION['id']."'";
	$result1=mysqli_query($con,$sql1);
	
	while ($row1=mysqli_fetch_array($result1)) {
		$productCountCart = $row1['product_count'];
		# code...
		$sql2 = "SELECT * FROM product_information WHERE product_id='".$row1['product_id']."'";
		$result2=mysqli_query($con,$sql2);
		$row2=mysqli_fetch_array($result2);

		$productCountProduct = $row2['remaining_products'];
		$productCount = $productCountProduct-$productCountCart;
		
		$soldProducts = $row2['sold_products'];
		echo $soldProducts."<br/>";
		$soldProducts+=$productCountCart;
		echo $soldProducts."<br/>";

		$sql3 = "UPDATE product_information SET sold_products='".$soldProducts ."',remaining_products='".$productCount."' WHERE product_id='".$row1['product_id']."'";
		$result3=mysqli_query($con,$sql3);
		$row3=mysqli_fetch_array($result3);

		$sql4 = "INSERT INTO orders(product_count,user_id,product_id,product_name,sell_price,image,date,received) VALUES('".$row1['product_count']."','".$_SESSION['id']."','".$row1['product_id']."','".$row1['product_name']."','".$row1['sell_price']."','".$row1['image']."','".$date."',0)";
		$result4=mysqli_query($con,$sql4);
		$row4=mysqli_fetch_array($result4);

		$sql5 = "DELETE FROM cart WHERE user_id='".$_SESSION['id']."'AND product_id='".$row1['product_id']."'";
		$result5=mysqli_query($con,$sql5);
		$row5=mysqli_fetch_array($result5);

	}
	header("Location:orderlist.php");
	
?>