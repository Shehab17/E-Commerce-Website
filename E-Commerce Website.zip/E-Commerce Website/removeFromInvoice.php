<?php
	session_start();
	$con=mysqli_connect("localhost","root","","db_connection");
	$sql="UPDATE orders SET received=1 WHERE user_id='".$_SESSION['id']."' AND  invoice_number='".$_GET['id']."'";
	if(mysqli_query($con,$sql))
	{
		header("Location:orderlist.php");
	}

?>