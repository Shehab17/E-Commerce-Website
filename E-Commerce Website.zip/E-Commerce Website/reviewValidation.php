<?php

	session_start();
	error_reporting(0);
	if(!empty($_POST['comments']))
	{
		$con=mysqli_connect("localhost","root","","db_connection");
		$sql="INSERT INTO `reviews`(`user_id`, `product_id`, `comments`) VALUES ('".$_SESSION['id']."','".$_GET['id']."','".$_POST['comments']."')";
		if(mysqli_query($con,$sql))
		{
			echo "Insert Done<br/>";
			header("Location:product.php?id=".$_GET['id']);

		}
		else
		{
			echo "Insert Error<br/>";
		}
	}
	else
	{
		echo "File is empty..<br/>";
	}

?>