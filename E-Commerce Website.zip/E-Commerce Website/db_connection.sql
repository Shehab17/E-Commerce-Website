-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 30, 2019 at 06:15 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_connection`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `product_count` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(500) NOT NULL,
  `sell_price` double NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `user_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `user_type` varchar(50) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`user_id`, `email`, `password`, `user_type`, `status`) VALUES
(1, 'smshabab36@gmail.com', '@@@@@@@@', 'Admin', 1),
(2, 'ananchaklader@gmail.com', 'password@', 'User', 1),
(3, 'shahriershawon@gmail.com', 'password@', 'User', 0),
(4, 'asfatrahman99@outlook.com', 'password@', 'User', 0);

-- --------------------------------------------------------

--
-- Table structure for table `messenger`
--

CREATE TABLE `messenger` (
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `invoice_number` int(11) NOT NULL,
  `product_count` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(500) NOT NULL,
  `sell_price` double NOT NULL,
  `image` varchar(500) NOT NULL,
  `date` varchar(50) NOT NULL,
  `received` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`invoice_number`, `product_count`, `user_id`, `product_id`, `product_name`, `sell_price`, `image`, `date`, `received`) VALUES
(13, 1, 2, 29, 'Seiko 5 SNK807', 68, 'image104.PNG', '2019-04-28', 1),
(14, 1, 2, 28, 'Seiko 5 SNK803', 68, 'image102.PNG', '2019-04-28', 1),
(15, 2, 1, 27, 'Seiko 5 SNK805', 68, 'image103.PNG', '2019-04-28', 0),
(16, 2, 1, 28, 'Seiko 5 SNK803', 68, 'image102.PNG', '2019-04-28', 0),
(17, 3, 2, 34, 'Seiko 5 SNK801', 70, 'image101.PNG', '2019-04-29', 1),
(18, 1, 2, 29, 'Seiko 5 SNK807', 68, 'image104.PNG', '2019-04-29', 1),
(19, 2, 2, 27, 'Seiko 5 SNK805', 68, 'image103.PNG', '2019-04-29', 0),
(20, 1, 2, 34, 'Seiko 5 SNK801', 70, 'image101.PNG', '2019-04-29', 1),
(21, 1, 2, 34, 'Seiko 5 SNK801', 70, 'image101.PNG', '2019-04-29', 0),
(22, 2, 4, 29, 'Seiko 5 SNK807', 68, 'image104.PNG', '2019-04-29', 1),
(23, 1, 4, 34, 'Seiko 5 SNK801', 70, 'image101.PNG', '2019-04-29', 1),
(24, 1, 4, 27, 'Seiko 5 SNK805', 68, 'image103.PNG', '2019-04-30', 1),
(25, 2, 4, 28, 'Seiko 5 SNK803', 68, 'image102.PNG', '2019-04-30', 1),
(26, 1, 4, 29, 'Seiko 5 SNK807', 68, 'image104.PNG', '2019-04-30', 0),
(27, 1, 4, 28, 'Seiko 5 SNK803', 68, 'image102.PNG', '2019-04-30', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_information`
--

CREATE TABLE `product_information` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(500) NOT NULL,
  `image1` varchar(500) NOT NULL,
  `image2` varchar(500) DEFAULT NULL,
  `image3` varchar(500) DEFAULT NULL,
  `description_header` varchar(500) NOT NULL,
  `sub_point_1` varchar(500) NOT NULL,
  `sub_point_2` varchar(500) NOT NULL,
  `sub_point_3` varchar(500) NOT NULL,
  `sub_point_4` varchar(500) NOT NULL,
  `sub_point_5` varchar(500) NOT NULL,
  `sub_point_6` varchar(500) NOT NULL,
  `sub_point_7` varchar(500) NOT NULL,
  `sub_point_8` varchar(500) NOT NULL,
  `sub_point_9` varchar(500) NOT NULL,
  `total_inventory` int(11) NOT NULL,
  `sold_products` int(11) NOT NULL,
  `remaining_products` int(11) NOT NULL,
  `original_price` double NOT NULL,
  `sell_price` double NOT NULL,
  `revenue` double NOT NULL,
  `discount` double NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_information`
--

INSERT INTO `product_information` (`product_id`, `product_name`, `image1`, `image2`, `image3`, `description_header`, `sub_point_1`, `sub_point_2`, `sub_point_3`, `sub_point_4`, `sub_point_5`, `sub_point_6`, `sub_point_7`, `sub_point_8`, `sub_point_9`, `total_inventory`, `sold_products`, `remaining_products`, `original_price`, `sell_price`, `revenue`, `discount`, `user_id`) VALUES
(27, 'Seiko 5 SNK805', 'image101.jpg', 'image101.jpg', 'image101.jpg', 'Specification:', 'aa', '37 mm stainless steel case with Hardlex dial window', 'Automatic self-wind movement with analog display. Case Back: Skeleton', 'Canvas band with buckle closure. Case thickness: 11 mm', 'Water resistant to 30 m (99 ft): In general, withstands splashes or brief immersion in water, but not suitable for swimming', 'Not solid breslet', 'Hardlex Minarel Crystal', 'Movement : 7S26 self-winding automatic', 'Seiko super-lumenova', 228, 5, 228, 60, 68, 8, 0, 2),
(28, 'Seiko 5 SNK803', 'image102.jpg', 'image102.jpg', 'image103.jpg', 'Specification:', 'aa', '37 mm stainless steel case with Hardlex dial window', 'Automatic self-wind movement with analog display. Case Back: Skeleton', 'Canvas band with buckle closure. Case thickness: 11 mm', 'Water resistant to 30 m (99 ft): In general, withstands splashes or brief immersion in water, but not suitable for swimming', 'Not solid breslet', 'Hardlex Minarel Crystal', 'Movement : 7S26 self-winding automatic', 'Seiko super-lumenova', 227, 6, 227, 60, 68, 8, 0, 2),
(29, 'Seiko 5 SNK807', 'image103.jpg', 'image103.jpg', 'image103.jpg', 'Specification:', 'aa', '37 mm stainless steel case with Hardlex dial window', 'Automatic self-wind movement with analog display. Case Back: Skeleton', 'Canvas band with buckle closure. Case thickness: 11 mm', 'Water resistant to 30 m (99 ft): In general, withstands splashes or brief immersion in water, but not suitable for swimming', 'Not solid breslet', 'Hardlex Minarel Crystal', 'Movement : 7S26 self-winding automatic', 'Seiko super-lumenova', 207, 5, 207, 60, 68, 8, 0, 2),
(34, 'Seiko 5 SNK801', 'image104.jpg', 'image104.jpg', 'image104.jpg', 'Specification:', 'Round watch featuring blue dial with day/date', '37 mm stainless steel case with Hardlex dial window', 'Automatic self-wind movement with analog display', 'Canvas band with buckle closure. Case thickness: 11 mm', 'Water resistant to 30 m (99 ft)', 'Not solid breslet', 'Hardlex Minarel Crystal', 'Movement : 7S26 self-winding automatic', 'Seiko super-lumenova', 51, 6, 51, 60, 70, 10, 0, 2),
(35, 'Seiko 5 Automatic Stainless Steel Watch', 'c5ed9bff-5473-48dd-a2b8-397594f2cbdf.jpg', 'c5ed9bff-5473-48dd-a2b8-397594f2cbdf.jpg', 'c5ed9bff-5473-48dd-a2b8-397594f2cbdf.jpg', 'Specification:', 'Round watch featuring blue dial with day/date', '37 mm stainless steel case with Hardlex dial window', 'Automatic self-wind movement with analog display', 'Canvas band with buckle closure. Case thickness: 11 mm', 'Water resistant to 30 m (99 ft)', 'Not solid breslet', 'Hardlex Minarel Crystal', 'Movement : 7S26 self-winding automatic', 'Seiko super-lumenova', 231, 0, 231, 60, 75, 15, 0, 2),
(37, 'Seiko 5 Automatic Stainless Steel Watch with Blue Canvas Band', 'gents-seiko-5-sports-automatic-orange-dial-rubber-strap-watch-p17248-23850_image.jpg', 'gents-seiko-5-sports-automatic-orange-dial-rubber-strap-watch-p17248-23850_image.jpg', 'gents-seiko-5-sports-automatic-orange-dial-rubber-strap-watch-p17248-23850_image.jpg', 'Specification:', 'Round watch featuring blue dial with day/date', '37 mm stainless steel case with Hardlex dial window', 'Automatic self-wind movement with analog display', 'Canvas band with buckle closure. Case thickness: 11 mm', 'Water resistant to 30 m (99 ft)', 'Not solid breslet', 'Hardlex Minarel Crystal', 'Movement : 7S26 self-winding automatic', 'Seiko super-lumenova', 123, 0, 123, 70, 78, 8, 0, 2),
(38, 'Seiko 5 Automatic Watch', 'img57263593.jpg', 'img57263593.jpg', 'img57263593.jpg', 'Specification:', 'Round watch featuring blue dial with day/date', '37 mm stainless steel case with Hardlex dial window', 'Automatic self-wind movement with analog display', 'Canvas band with buckle closure. Case thickness: 11 mm', 'Water resistant to 30 m (99 ft)', 'Not solid breslet', 'Hardlex Minarel Crystal', 'Movement : 7S26 self-winding automatic', 'Seiko super-lumenova', 111, 0, 111, 80, 90, 10, 0, 2),
(40, 'Seiko 5 Automatic Stainless Steel Watch with Blue Canvas Band', 'seiko-5-gold-tone-automatic-mens-watch-snxl72.jpg', 'seiko-5-gold-tone-automatic-mens-watch-snxl72.jpg', 'seiko-5-gold-tone-automatic-mens-watch-snxl72.jpg', 'Specification:', 'Round watch featuring blue dial with day/date', '37 mm stainless steel case with Hardlex dial window', 'Automatic self-wind movement with analog display', 'Canvas band with buckle closure. Case thickness: 11 mm', 'Water resistant to 30 m (99 ft)', 'Not solid breslet', 'Hardlex Minarel Crystal', 'Movement : 7S26 self-winding automatic', 'Seiko super-lumenova', 111, 0, 111, 70, 80, 10, 0, 4),
(41, 'Seiko 5 Automatic Stainless Steel Watch', 'SNKK71K1_20AKOR350_1__05314.1534120612.1280.1280.jpg', 'SNKK71K1_20AKOR350_1__05314.1534120612.1280.1280.jpg', 'SNKK71K1_20AKOR350_1__05314.1534120612.1280.1280.jpg', 'Specification:', 'Round watch featuring blue dial with day/date', '37 mm stainless steel case with Hardlex dial window', 'Automatic self-wind movement with analog display', 'Canvas band with buckle closure. Case thickness: 11 mm', 'Water resistant to 30 m (99 ft)', 'Not solid breslet', 'Hardlex Minarel Crystal', 'Movement : 7S26 self-winding automatic', 'Seiko super-lumenova', 123, 0, 123, 80, 90, 10, 0, 4),
(42, 'Seiko 5 Automatic Stainless Steel Watch with Blue Canvas Band', 'snke09j1_00_3.jpg', 'snke09j1_00_3.jpg', 'snke09j1_00_3.jpg', 'Specification:', 'Round watch featuring blue dial with day/date', '37 mm stainless steel case with Hardlex dial window', 'Automatic self-wind movement with analog display', 'Canvas band with buckle closure. Case thickness: 11 mm', 'Water resistant to 30 m (99 ft)', 'Not solid breslet', 'Hardlex Minarel Crystal', 'Movement : 7S26 self-winding automatic', 'Seiko super-lumenova', 123, 0, 123, 90, 100, 10, 0, 4);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `comments` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`user_id`, `product_id`, `comments`) VALUES
(4, 0, 'sdfsdfsd'),
(4, 27, 'Good Watch... Highly recommend it.... :)'),
(4, 27, 'Good Quality Products....'),
(4, 29, 'Good Watch... Highly recommend it.... :)'),
(4, 29, 'Nice mood but the price is same .... Nice one...'),
(2, 27, 'Nice mood but the price is same .... Nice one...'),
(4, 35, 'Good Watch... Highly recommend it.... :)'),
(4, 35, 'Nice mood but the price is same .... Nice one...'),
(4, 28, 'gfhcnfcngfngfdngf');

-- --------------------------------------------------------

--
-- Table structure for table `user_information`
--

CREATE TABLE `user_information` (
  `user_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `date_of_birth` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_information`
--

INSERT INTO `user_information` (`user_id`, `name`, `gender`, `date_of_birth`, `address`) VALUES
(1, 'Sheikh Shabab', 'male', '22-07-1995', '842/1 west kazipara mirpur, Dhaka-1216'),
(2, 'Anan Chaklader', 'male', '14-10-1998', 'abc'),
(3, 'Shahrier Shawon', 'male', '08-09-1996', 'nikunjo rode-2'),
(4, 'Asfat Rahman', 'male', '22-07-1995', '842/1 west kazipara mirpur');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`invoice_number`);

--
-- Indexes for table `product_information`
--
ALTER TABLE `product_information`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `user_information`
--
ALTER TABLE `user_information`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `invoice_number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `product_information`
--
ALTER TABLE `product_information`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `user_information`
--
ALTER TABLE `user_information`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
