<!DOCTYPE html>
<html>
<head>
	<title>PAYMENT METHODS</title>
</head>
<body>
	<table border="1" width="100%" cellspacing="0">
		<tr height="50">
			<td align="center" width="5%" style="background-color:#333333">
				<a href="index.php"><img src="image0.png" height="50"></a>
			</td>
			<td align="center" width="15%" style="background-color:Orange">
				<h2><b>Select a payment method</b></h2>
			</td>
			<td align="center" width="80%" style="background-color:Orange">
				<table border="1" width="100%" cellspacing="0">
						<tr height="50">
							<td width="85%" align="center">
								<input type="text" name="searchfield" size="150%" height="50">
								<input type="button" name="searchbutton" value="Search" onclick="location.href='search.php'">
							</td>
							<td width="5%" align="center">
								<input type="button" name="cart" value="Cart" onclick="location.href='cart.php'">
							</td>
							<td width="5%" align="center">
								<input type="button" name="logout" value="LogOut" onclick="location.href='login.php'">
							</td>
						</tr>
				</table>
			</td>
		</tr>
		<tr height="800">
			<td colspan="3" align="center">
				<table border="1" width="50%" cellspacing="0">
					<tr width="50%">
						<td align="center" width="50%">
							<img margin-left="20" src="bkash.png" height="200">
							<h3>$10,687</h3>
							<h5>pay from bkash number or payment</h5>
							<input type="button" value="Pay with bkash" onclick="location.href='bkashpayment.php'">
						</td>
						<td align="center" width="50%">
							<img src="creditcard.png" height="200">
							<h3>$10,187</h3>
							<h5>Pay by your mastercard,visa or internet banking</h5>
							<input type="submit" value="Pay with Card">
						</td>
					</tr>
					<tr width="50%">
						<td align="center" width="50%">
							<img src="electroicfund.png" height="200">
							<h3>$11,187</h3>
							<h5>Pay via electronic fund transfer</h5>
							<input type="submit" value="Pay with EFL">
						</td>
						<td align="center" width="50%">
							<img src="check.jpg" height="200">
							<h3>$11,687</h3>
							<h5>Pay with cash from your nearest branch of Bank asia</h5>
							<input type="submit" value="Pay with Cash Deposit">
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr height="50" style="background-color:Orange">
			<td colspan="3">
				<table width="100%" cellpadding="0" border="0">
					<tr height="50">
						<td align="left" width="50%">
							&nbsp;&nbsp;&nbsp;<b><font color="red">CONTACT US :&nbsp;&nbsp;</font><a href="mailto:si.shehab1997@gmail.com">SI.SHEHAB1997@GMAIL.COM</a></b>
						</td>
						<td align="right" width="50%">
							© COPYRIGHT 2018 H CO.LTD ALL RIGHT RESERVED&nbsp;&nbsp;&nbsp;
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>