<?php
	session_start();
	//error_reporting(0);

	if(isset($_POST['submit']))
	{
		$productName = trim($_POST['productName']);
		echo "1. ".$productName."<br/>";
		$descriptionHeader = trim($_POST['text0']);
		echo "2. ".$descriptionHeader."<br/>";
		$subPoint1 = trim($_POST['text1']);
		echo "3. ".$subPoint1."<br/>";
		$subPoint2 = trim($_POST['text2']);
		echo "4. ".$subPoint2."<br/>";
		$subPoint3 = trim($_POST['text3']);
		echo "5. ".$subPoint3."<br/>";
		$subPoint4 = trim($_POST['text4']);
		echo "6. ".$subPoint4."<br/>";
		$subPoint5 = trim($_POST['text5']);
		echo "7. ".$subPoint5."<br/>";
		$subPoint6 = trim($_POST['text6']);
		echo "8. ".$subPoint6."<br/>";
		$subPoint7 = trim($_POST['text7']);
		echo "9. ".$subPoint7."<br/>";
		$subPoint8 = trim($_POST['text8']);
		echo "10. ".$subPoint8."<br/>";
		$subPoint9 = trim($_POST['text9']);
		echo "11. ".$subPoint9."<br/>";
		$originalPrice = trim($_POST['oprice']);
		echo "12. ".$originalPrice."<br/>";
		$sellPrice = trim($_POST['sprice']);
		echo "13. ".$sellPrice."<br/>";
		$inventory = trim($_POST['inventory']);
		echo "14. ".$inventory."<br/>";
		$discount = trim($_POST['discount']);
		echo "15. ".$discount."<br/>";
		$image1 = basename($_FILES["fileToUpload1"]["name"]);
		echo "16. ".$image1."<br/>";
		$image2 = basename($_FILES["fileToUpload2"]["name"]);
		echo "17. ".$image2."<br/>";
		$image3 = basename($_FILES["fileToUpload3"]["name"]);
		echo "18. ".$image3."<br/>";
		if(empty($productName) || empty($descriptionHeader) || empty($subPoint1) || empty($subPoint2)|| empty($subPoint3)|| empty($subPoint4)|| empty($subPoint5)|| empty($subPoint6)|| empty($subPoint7)|| empty($subPoint8)|| empty($subPoint9)|| empty($originalPrice)|| empty($sellPrice)|| empty($inventory)|| $discount=="" || empty($image1) || empty($image2) || empty($image3))
		{
			echo "Can not be empty.<br/>";
			
		}
		else
		{

			$target_dir = "image/";
			$target_file1 = $target_dir . basename($_FILES["fileToUpload1"]["name"]);
			echo $target_file1."<br/>";
			$target_file2 = $target_dir . basename($_FILES["fileToUpload2"]["name"]);
			echo $target_file2."<br/>";
			$target_file3 = $target_dir . basename($_FILES["fileToUpload3"]["name"]);
			echo $target_file3."<br/>";
			
			$uploadOk = 1;
			$imageFileType1 = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));
			echo $imageFileType1."<br/>";
			$imageFileType2 = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));
			echo $imageFileType2."<br/>";
			$imageFileType3 = strtolower(pathinfo($target_file3,PATHINFO_EXTENSION));
			echo $imageFileType3."<br/>";
			
			// Check if image file is a actual image or fake image
			
		    $check1 = getimagesize($_FILES["fileToUpload1"]["tmp_name"]);
		    echo $check1."<br/>";
		    $check2 = getimagesize($_FILES["fileToUpload2"]["tmp_name"]);
		    echo $check2."<br/>";
		    $check3 = getimagesize($_FILES["fileToUpload3"]["tmp_name"]);
		    echo $check3."<br/>";
		    
		    if($check1 !== false) {
		        echo "File 1 is an image - " . $check1["mime"] . ".<br/>";
		        $uploadOk = 1;
		        if($check2 !== false) {
			        echo "File 2 is an image - " . $check2["mime"] . ".<br/>";
			        $uploadOk = 1;
			        if($check3 !== false) {
				        echo "File 3 is an image - " . $check3["mime"] . ".<br/>";
				        $uploadOk = 1;
				    }
				    else 
				    {
				        echo "File 3 is not an image.";
				        $uploadOk = 0;
				    } 		
		    	} 
		    	else {
			        echo "File 2 is not an image.";
			        $uploadOk = 0;	
		    	}
		    } 
		    else {
		        echo "File 1 is not an image.";
		        $uploadOk = 0;
		    }

			// Check file size
			if ($_FILES["fileToUpload1"]["size"] > 4000000) 
			{
			    echo "Sorry, your file is too large.";
			    $uploadOk = 0;
			}
			else if($_FILES["fileToUpload2"]["size"] > 4000000)
			{
				echo "Sorry, your file is too large.";
			    $uploadOk = 0;
			}
			else if($_FILES["fileToUpload3"]["size"] > 4000000)
			{
				echo "Sorry, your file is too large.";
			    $uploadOk = 0;
			}else{}

			// Allow certain file formats
			if($imageFileType1 != "jpg" && $imageFileType1 != "png" && $imageFileType1 != "jpeg"
			&& $imageFileType1 != "gif" ) {
			    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			    $uploadOk = 0;
			}
			else if($imageFileType2 != "jpg" && $imageFileType2 != "png" && $imageFileType2 != "jpeg"
			&& $imageFileType2 != "gif" ) {
			    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			    $uploadOk = 0;
			}
			else if($imageFileType3 != "jpg" && $imageFileType3 != "png" && $imageFileType3 != "jpeg"
			&& $imageFileType3 != "gif" ) {
			    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			    $uploadOk = 0;
			}else{}




			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
			    echo "Sorry, your file was not uploaded.<br/>";
			// if everything is ok, try to upload file
			} else {
				echo "Files are oke.<br/>";
			    if (move_uploaded_file($_FILES["fileToUpload1"]["tmp_name"], "image/".$_FILES["fileToUpload1"]["name"]) &&
					move_uploaded_file($_FILES["fileToUpload2"]["tmp_name"], "image/".$_FILES["fileToUpload2"]["name"]) &&
					move_uploaded_file($_FILES["fileToUpload3"]["tmp_name"], "image/".$_FILES["fileToUpload3"]["name"])) {
					echo "Completely Oke.<br/>";
					$temp = bcsub($sellPrice, $originalPrice); 
			    	echo $temp."<br/>";
					$con=mysqli_connect("localhost","root","","db_connection");

			     	echo $productName."<br/>";
			     	echo $subPoint1."<br/>";
			     	$sql = "INSERT INTO `product_information`( `product_name`, `image1`, `image2`, `image3`, `description_header`, `sub_point_1`, `sub_point_2`, `sub_point_3`, `sub_point_4`, `sub_point_5`, `sub_point_6`, `sub_point_7`, `sub_point_8`, `sub_point_9`, `total_inventory`, `sold_products`, `remaining_products`, `original_price`, `sell_price`, `revenue`, `discount`, `user_id`) 
			     	VALUES 
			     	('".$productName."', '".basename( $_FILES["fileToUpload1"]["name"])."', '".basename( $_FILES["fileToUpload2"]["name"])."', '".basename( $_FILES["fileToUpload3"]["name"])."', '".$descriptionHeader."', '".$subPoint1."', '".$subPoint2."', '".$subPoint3."', '".$subPoint4."', '".$subPoint5."', '".$subPoint6."', '".$subPoint7."', '".$subPoint8."', '".$subPoint9."', ".$inventory.", 0, ".$inventory.", ".$originalPrice.", ".$sellPrice.", ".$temp.", ".$discount.", ".$_SESSION['id'].")";
			     	//$sql2="select * from product_information";
			        if(mysqli_query($con,$sql))
					{
						echo "Data Inserted.<br/>";
						header("Location:user.php?page=updateProducts");
					}
					else
					{
						echo "Insert Error.<br/>";
					}


			    } else {
			        echo "Sorry, there was an error moving your file.";
			    }
			}
		}
	}
	else
	{
		echo "You are not allowed.<br/>";
	}


?>